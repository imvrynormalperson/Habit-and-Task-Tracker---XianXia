export type QuestDifficulty = 'easy' | 'normal' | 'hard' | 'tribulation';
export type QuestType = 'daily' | 'side';
export type QuestCategory = 'all' | 'mind' | 'body' | 'craft' | 'spirit';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Quest {
  id: string;
  title: string;
  type: QuestType;
  difficulty: QuestDifficulty;
  category: QuestCategory;
  done: boolean;
  streak?: number;
  subtasks?: Subtask[];
  createdAt: string;
  lastCompletedDate?: string;
}

export interface CultivationRealm {
  tier: number;
  minLevel: number;
  name: string;
  chineseName: string;
  description: string;
  emoji: string;
  color: string;
}

export interface DemonBoss {
  id: string;
  name: string;
  title: string;
  flavor: string;
  emoji: string;
  hp: number;
  maxHp: number;
  dateAssigned: string;
  defeated: boolean;
  rewardStones: number;
  rewardHerb: string;
}

export interface BattleLogEntry {
  id: string;
  text: string;
  kind: 'good' | 'bad' | 'epic' | 'neutral';
  timestamp: string;
}

export interface HerbInventory {
  ginseng: number;     // Spirit Ginseng (from Mind tasks)
  dragonGrass: number; // Dragon Bone Grass (from Body tasks)
  netherLotus: number; // Nether Lotus (from Spirit tasks)
  celestialDew: number;// Celestial Dew (from Streaks & Bosses)
}

export interface PillRecipe {
  id: string;
  name: string;
  chineseName: string;
  description: string;
  costStones: number;
  ingredients: Partial<HerbInventory>;
  effectDescription: string;
  type: 'shield' | 'freeze' | 'qiBoost' | 'coinBoost' | 'heal' | 'elixir';
}

export interface RobeSkin {
  id: string;
  name: string;
  title: string;
  cost: number;
  emoji: string;
  description: string;
  perk: string;
}

export interface CaveArray {
  id: string;
  name: string;
  description: string;
  baseCost: number;
  currentLevel: number;
  maxLevel: number;
  bonusText: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  emoji: string;
  rewardStones: number;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface CultivatorState {
  level: number;
  xp: number;
  hp: number;
  maxHp: number;
  coins: number;
  streak: number;
  bestStreak: number;
  lastActiveDate: string;
  prestige: number;
  activeSkin: string;
  unlockedSkins: string[];
  shieldCharges: number;
  freezeCharges: number;
  qiBoostCharges: number;
  coinBoostCharges: number;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  quests: Quest[];
  boss: DemonBoss | null;
  battleLog: BattleLogEntry[];
  herbs: HerbInventory;
  arrays: Record<string, number>;
  unlockedAchievements: string[];
  historyLog: Record<string, number>; // date -> count completed
  stats: {
    totalCompleted: number;
    bossesDefeated: number;
    pillsRefined: number;
    breakthroughsAchieved: number;
    hasFallenBefore: boolean;
  };
}
