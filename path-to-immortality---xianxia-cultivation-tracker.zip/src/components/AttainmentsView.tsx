import React from 'react';
import { useCultivation } from '../context/CultivationContext';
import { CULTIVATION_REALMS, ACHIEVEMENTS_LIST } from '../data/cultivationData';
import { Award, Zap, CheckCircle2, Lock, Flame, Calendar } from 'lucide-react';

export const AttainmentsView: React.FC = () => {
  const { state, performAscension } = useCultivation();

  const canAscend = state.level >= 15;

  // Generate last 28 days for activity heatmap
  const today = new Date();
  const pastDays = Array.from({ length: 28 }).map((_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (27 - i));
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const count = state.historyLog[key] || 0;
    return { date: key, count, dayOfWeek: d.toLocaleDateString([], { weekday: 'narrow' }) };
  });

  return (
    <div className="w-full space-y-6">
      {/* Heavenly Ascension (Prestige) Altar */}
      <div className="bg-gradient-to-r from-[#1c2b26] via-[#131f1c] to-[#1c2b26] border-2 border-[#d4af37] rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-[#d4af37]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#d4af37] font-cinzel font-bold mb-1">
              <Zap className="w-4 h-4" />
              <span>Celestial Altar of Rebirth</span>
            </div>
            <h2 className="font-cinzel font-bold text-lg sm:text-xl text-[#f2ead2] mb-1">
              Heavenly Ascension
            </h2>
            <p className="text-xs text-[#9fb3a4] max-w-lg leading-relaxed">
              Upon reaching Level 15 (Soul Formation), a cultivator may transcend mortality: reset to Level 1, gaining a permanent +8% bonus to all Qi and Spirit Stones gained, plus 3 rare Celestial Dews. All unlocked robes, arrays, and attainments are kept forever.
            </p>
          </div>

          <div className="text-right shrink-0 w-full sm:w-auto">
            {state.prestige > 0 && (
              <div className="text-xs text-[#d4af37] font-cinzel font-semibold mb-2">
                Ascensions Attained: {state.prestige}
              </div>
            )}
            <button
              onClick={() => {
                if (window.confirm('Are you ready to transcend the mortal plane and undergo Heavenly Ascension? Your level will reset to 1 with permanent bonuses!')) {
                  performAscension();
                }
              }}
              disabled={!canAscend}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f59e0b] text-[#0a0f0e] font-cinzel font-bold text-xs sm:text-sm hover:brightness-110 active:scale-95 transition shadow-lg shadow-[#d4af37]/20 disabled:opacity-40 cursor-pointer"
            >
              {canAscend ? 'Begin Ascension' : `Requires Level 15 (Currently Lv.${state.level})`}
            </button>
          </div>
        </div>
      </div>

      {/* 28-Day Cultivation Activity Heatmap */}
      <div className="bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-cinzel text-xs sm:text-sm font-bold text-[#f2ead2] flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#5fe0a4]" />
            28-Day Cultivation Constellation
          </h3>
          <span className="text-xs text-[#9fb3a4] font-mono">
            Longest Streak: <strong className="text-amber-400">{state.bestStreak}d</strong>
          </span>
        </div>

        <div className="grid grid-cols-7 sm:grid-cols-14 gap-1.5 sm:gap-2 pt-2">
          {pastDays.map(day => {
            const levelClass =
              day.count >= 4
                ? 'bg-[#5fe0a4] border-[#5fe0a4]'
                : day.count >= 2
                ? 'bg-[#2f9e6e] border-[#2f9e6e]'
                : day.count >= 1
                ? 'bg-[#1c4433] border-[#2c5443]'
                : 'bg-[#0a0f0e] border-[#2c4438]/60';

            return (
              <div
                key={day.date}
                className="flex flex-col items-center gap-1 group relative cursor-pointer"
                title={`${day.date}: ${day.count} tasks completed`}
              >
                <div
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg border flex items-center justify-center text-[10px] font-mono font-bold transition-all group-hover:scale-110 ${levelClass}`}
                >
                  {day.count > 0 && (
                    <span className={day.count >= 2 ? 'text-[#08120e]' : 'text-[#f2ead2]'}>
                      {day.count}
                    </span>
                  )}
                </div>
                <span className="text-[9px] text-[#9fb3a4] uppercase font-mono">
                  {day.dayOfWeek}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Realms Progression Roadmap */}
      <div className="bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4 sm:p-5">
        <h3 className="font-cinzel text-xs sm:text-sm font-bold text-[#f2ead2] mb-3 flex items-center gap-2">
          <Flame className="w-4 h-4 text-[#d4af37]" />
          Cultivation Realms Hierarchy
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {CULTIVATION_REALMS.map(realm => {
            const isReached = state.level >= realm.minLevel;
            const isCurrent = state.level >= realm.minLevel && (
              realm.tier === CULTIVATION_REALMS.length || state.level < CULTIVATION_REALMS[realm.tier].minLevel
            );

            return (
              <div
                key={realm.tier}
                className={`p-3.5 rounded-xl border transition-all ${
                  isCurrent
                    ? 'bg-[#1c2b26] border-[#5fe0a4] shadow-md shadow-[#5fe0a4]/10'
                    : isReached
                    ? 'bg-[#131f1c] border-[#2c4438]'
                    : 'bg-[#0a0f0e]/60 border-[#2c4438]/40 opacity-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{realm.emoji}</span>
                    <div>
                      <div className="font-cinzel font-bold text-xs text-[#f2ead2] flex items-center gap-1.5">
                        <span>{realm.name}</span>
                        {isCurrent && (
                          <span className="text-[10px] bg-[#5fe0a4] text-[#08120e] font-sans font-bold px-1.5 py-0.2 rounded-md">
                            Current
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-[#5fe0a4] font-cinzel">
                        {realm.chineseName}
                      </div>
                    </div>
                  </div>

                  <span className="font-mono text-[11px] text-[#9fb3a4]">
                    Lv.{realm.minLevel}+
                  </span>
                </div>

                <p className="text-[11px] text-[#9fb3a4] leading-relaxed">
                  {realm.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Attainments (Achievements) List */}
      <div className="bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-cinzel text-xs sm:text-sm font-bold text-[#f2ead2] flex items-center gap-2">
            <Award className="w-4 h-4 text-[#d4af37]" />
            Cultivation Attainments
          </h3>
          <span className="text-xs text-[#5fe0a4] font-mono">
            {state.unlockedAchievements.length} / {ACHIEVEMENTS_LIST.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {ACHIEVEMENTS_LIST.map(ach => {
            const isUnlocked = state.unlockedAchievements.includes(ach.id);

            return (
              <div
                key={ach.id}
                className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition ${
                  isUnlocked
                    ? 'bg-[#1c2b26] border-[#2f9e6e]'
                    : 'bg-[#0a0f0e] border-[#2c4438]/50 opacity-55'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="text-2xl shrink-0">
                    {isUnlocked ? ach.emoji : '🔒'}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-cinzel font-bold text-xs text-[#f2ead2] truncate">
                      {ach.title}
                    </h4>
                    <p className="text-[11px] text-[#9fb3a4] leading-snug">
                      {ach.description}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  {isUnlocked ? (
                    <span className="text-xs text-[#5fe0a4] font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Attained
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono text-[#d4af37]">
                      +{ach.rewardStones} Stones
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
