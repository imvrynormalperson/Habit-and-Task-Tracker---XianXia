import React, { useState } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Sparkles, Volume2, VolumeX, Vibrate, Download, Scroll, HelpCircle } from 'lucide-react';

interface HeaderProps {
  onOpenDaoScroll: () => void;
  onOpenBreakthrough: () => void;
  onOpenHelp: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenDaoScroll, onOpenBreakthrough, onOpenHelp }) => {
  const { state, currentRealm, readyForBreakthrough, toggleSound, toggleHaptics } = useCultivation();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSPrompt, setShowIOSPrompt] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0a0f0e]/95 backdrop-blur-md border-b border-[#2c4438]/80 px-4 py-2.5 transition-all">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Zone */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-[#2f9e6e] to-[#131f1c] border border-[#5fe0a4]/40 flex items-center justify-center shadow-lg shadow-[#2f9e6e]/10">
            <span className="text-lg select-none">{currentRealm.emoji}</span>
            <div className="absolute -bottom-1 -right-1 bg-[#d4af37] text-[#0a0f0e] font-cinzel font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center border border-[#0a0f0e]">
              {state.level}
            </div>
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="font-cinzel font-bold text-sm sm:text-base text-[#f2ead2] tracking-wide truncate">
                Path to Immortality
              </h1>
              {state.prestige > 0 && (
                <span className="text-[#d4af37] text-xs font-cinzel font-bold shrink-0">
                  {'★'.repeat(Math.min(state.prestige, 5))}
                </span>
              )}
            </div>
            <div className="text-[11px] text-[#9fb3a4] truncate flex items-center gap-1">
              <span>{currentRealm.chineseName}</span>
              <span className="opacity-50">·</span>
              <span className="text-[#5fe0a4] font-medium">{currentRealm.name}</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Breakthrough CTA when ready */}
          {readyForBreakthrough && (
            <button
              onClick={onOpenBreakthrough}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#d4af37] to-[#eab308] text-[#0a0f0e] font-cinzel font-bold text-xs shadow-md shadow-[#d4af37]/20 hover:brightness-110 active:scale-95 transition cursor-pointer animate-pulse"
              title="Ascend to next cultivation level"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Breakthrough</span>
            </button>
          )}

          {/* Android PWA Install Button */}
          {!isInstalled && isInstallable && (
            <button
              onClick={install}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#2f9e6e] text-[#08120e] hover:bg-[#5fe0a4] font-semibold text-xs transition active:scale-95 shadow-sm cursor-pointer"
              title="Install Android App"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Install App</span>
              <span className="sm:hidden">App</span>
            </button>
          )}

          {/* iOS Safari Install Button */}
          {!isInstalled && isIOS && (
            <button
              onClick={() => setShowIOSPrompt(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#2c4438] bg-[#131f1c] text-[#f2ead2] hover:border-[#5fe0a4] text-xs transition cursor-pointer"
              title="Install on iOS"
            >
              <Download className="w-3.5 h-3.5 text-[#5fe0a4]" />
              <span className="hidden sm:inline">Install</span>
            </button>
          )}

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            aria-label="Toggle sound"
            className="w-8 h-8 rounded-lg bg-[#131f1c] border border-[#2c4438] hover:border-[#5fe0a4]/50 flex items-center justify-center text-[#9fb3a4] hover:text-[#f2ead2] transition cursor-pointer"
            title={state.soundEnabled ? 'Mute Sound (Web Audio)' : 'Enable Sound'}
          >
            {state.soundEnabled ? <Volume2 className="w-4 h-4 text-[#5fe0a4]" /> : <VolumeX className="w-4 h-4 opacity-50" />}
          </button>

          {/* Haptics Toggle */}
          <button
            onClick={toggleHaptics}
            aria-label="Toggle haptics"
            className="w-8 h-8 rounded-lg bg-[#131f1c] border border-[#2c4438] hover:border-[#5fe0a4]/50 flex items-center justify-center text-[#9fb3a4] hover:text-[#f2ead2] transition cursor-pointer"
            title={state.hapticsEnabled ? 'Disable Vibration' : 'Enable Vibration'}
          >
            <Vibrate className={`w-4 h-4 ${state.hapticsEnabled ? 'text-[#5fe0a4]' : 'opacity-50'}`} />
          </button>

          {/* Guide / Lore */}
          <button
            onClick={onOpenHelp}
            aria-label="Cultivation manual"
            className="w-8 h-8 rounded-lg bg-[#131f1c] border border-[#2c4438] hover:border-[#5fe0a4]/50 flex items-center justify-center text-[#9fb3a4] hover:text-[#f2ead2] transition cursor-pointer"
            title="Cultivation Manual"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Backup & Settings Scroll */}
          <button
            onClick={onOpenDaoScroll}
            aria-label="Dao scroll backup"
            className="w-8 h-8 rounded-lg bg-[#131f1c] border border-[#2c4438] hover:border-[#d4af37]/60 flex items-center justify-center text-[#d4af37] transition cursor-pointer"
            title="Dao Record & Backup"
          >
            <Scroll className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* iOS Modal */}
      {showIOSPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#131f1c] border border-[#2c4438] p-5 shadow-2xl">
            <h3 className="font-cinzel font-bold text-base text-[#f2ead2] mb-2 flex items-center gap-2">
              <Download className="w-4 h-4 text-[#5fe0a4]" />
              Install on iOS Device
            </h3>
            <p className="text-xs text-[#9fb3a4] leading-relaxed mb-4">
              1. Tap the <strong className="text-[#f2ead2]">Share</strong> button in Safari toolbar.<br />
              2. Scroll down and tap <strong className="text-[#5fe0a4]">Add to Home Screen</strong>.<br />
              3. Launch the app from your home screen for the full immersive cultivation experience!
            </p>
            <button
              onClick={() => setShowIOSPrompt(false)}
              className="w-full py-2.5 rounded-xl bg-[#2f9e6e] text-[#08120e] font-semibold text-xs hover:bg-[#5fe0a4] transition cursor-pointer"
            >
              Understood
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
