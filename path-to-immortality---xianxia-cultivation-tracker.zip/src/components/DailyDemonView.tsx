import React, { useState } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { Swords, Shield, Skull, CheckCircle2, History, Zap } from 'lucide-react';
import demonBossImg from '../assets/images/inner_demon_boss_1790168734309.jpg';

export const DailyDemonView: React.FC = () => {
  const { state, strikeDemonWithSwordQi } = useCultivation();
  const [strikeFeedback, setStrikeFeedback] = useState<{ dmg: number; crit: boolean } | null>(null);

  const boss = state.boss;
  if (!boss) {
    return (
      <div className="w-full bg-[#131f1c] border border-[#2c4438] rounded-2xl p-8 text-center text-[#9fb3a4]">
        <Skull className="w-12 h-12 mx-auto mb-3 opacity-40" />
        <p className="font-cinzel text-sm">No Inner Demon detected today. Your Dao Heart is crystal clear.</p>
      </div>
    );
  }

  const hpPercent = Math.max(0, Math.min(100, Math.round((boss.hp / boss.maxHp) * 100)));

  const handleSwordQiStrike = () => {
    const res = strikeDemonWithSwordQi();
    if (res) {
      setStrikeFeedback(res);
      setTimeout(() => setStrikeFeedback(null), 2000);
    }
  };

  return (
    <div className="w-full space-y-4">
      {/* Demon Card */}
      <div className="w-full bg-[#131f1c] border border-[#2c4438] rounded-2xl overflow-hidden shadow-2xl relative">
        {/* Background art banner overlay */}
        <div className="relative h-48 sm:h-56 w-full overflow-hidden bg-[#0a0f0e]">
          <img
            src={demonBossImg}
            alt={boss.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center brightness-75 contrast-125 transition-transform hover:scale-105 duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131f1c] via-[#131f1c]/40 to-transparent" />

          {/* Defeated Stamp */}
          {boss.defeated && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-xs">
              <div className="border-4 border-[#5fe0a4] text-[#5fe0a4] font-cinzel font-black text-xl sm:text-2xl px-6 py-2 rounded-xl rotate-[-8deg] tracking-widest shadow-2xl bg-[#0a0f0e]/80 flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6" />
                DEMON SUBDUED
              </div>
            </div>
          )}

          {/* Floating Crit Floater */}
          {strikeFeedback && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-20 animate-bounce">
              <div className={`px-4 py-2 rounded-xl font-cinzel font-black text-base shadow-2xl border ${strikeFeedback.crit ? 'bg-amber-400 text-black border-yellow-200 text-lg' : 'bg-rose-600 text-white border-rose-400'}`}>
                {strikeFeedback.crit ? 'CRITICAL ' : ''}-{strikeFeedback.dmg} HP!
              </div>
            </div>
          )}

          {/* Top badge */}
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0a0f0e]/80 border border-rose-500/40 text-rose-300 text-xs font-cinzel">
            <Skull className="w-3.5 h-3.5 text-rose-400" />
            <span>Today's Inner Demon</span>
          </div>

          <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-[#0a0f0e]/80 border border-[#2c4438] text-xs font-mono text-[#d4af37]">
            +{boss.rewardStones} Stones on Defeat
          </div>
        </div>

        {/* Demon Info & Combat Bar */}
        <div className="p-4 sm:p-6 -mt-6 relative z-10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{boss.emoji}</span>
                <h2 className="font-cinzel font-bold text-lg sm:text-xl text-[#f2ead2]">
                  {boss.name}
                </h2>
              </div>
              <div className="text-xs text-rose-400 font-medium">
                {boss.title}
              </div>
            </div>

            <div className="text-right">
              <span className="font-mono text-sm font-bold text-rose-400 tabular-nums">
                {boss.hp} / {boss.maxHp} HP
              </span>
              <span className="text-xs text-[#9fb3a4] block">({hpPercent}%)</span>
            </div>
          </div>

          {/* Demon HP Bar */}
          <div className="h-4 w-full bg-[#0a0f0e] rounded-full border border-[#2c4438] overflow-hidden p-0.5 mb-3 shadow-inner">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                boss.defeated
                  ? 'bg-slate-700'
                  : 'bg-gradient-to-r from-rose-700 via-rose-500 to-amber-500'
              }`}
              style={{ width: `${hpPercent}%` }}
            />
          </div>

          <p className="text-xs text-[#9fb3a4] italic leading-relaxed mb-4 bg-[#0a0f0e]/50 p-3 rounded-xl border border-[#2c4438]/50">
            "{boss.flavor}"
          </p>

          {/* Combat Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleSwordQiStrike}
              disabled={boss.defeated}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-rose-700 to-rose-600 hover:from-rose-600 hover:to-rose-500 text-white font-cinzel font-bold text-xs sm:text-sm shadow-lg shadow-rose-900/30 flex items-center justify-center gap-2 transition active:scale-98 disabled:opacity-40 cursor-pointer"
            >
              <Swords className="w-4 h-4" />
              <span>Strike with Sword Qi</span>
            </button>
          </div>

          {/* Heart Shield & Backlash Mechanics Note */}
          <div className="mt-4 pt-4 border-t border-[#2c4438] flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between text-xs text-[#9fb3a4]">
            <div className="flex items-center gap-2">
              <Shield className={`w-4 h-4 ${state.shieldCharges > 0 ? 'text-[#5fe0a4]' : 'text-[#9fb3a4]'}`} />
              <span>
                {state.shieldCharges > 0 ? (
                  <strong className="text-[#5fe0a4]">
                    {state.shieldCharges} Heart Shield(s) active
                  </strong>
                ) : (
                  <span>No shields active. Missing tasks tonight causes Dao Heart damage!</span>
                )}
              </span>
            </div>
            <div className="text-[11px] text-[#5fe0a4] flex items-center gap-1">
              <Zap className="w-3 h-3 text-[#d4af37]" />
              <span>Completing daily tasks inflicts massive damage!</span>
            </div>
          </div>
        </div>
      </div>

      {/* Battle Log */}
      <div className="w-full bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4 sm:p-5 shadow-lg">
        <h3 className="font-cinzel font-bold text-xs sm:text-sm text-[#f2ead2] mb-3 flex items-center gap-2">
          <History className="w-4 h-4 text-[#5fe0a4]" />
          Cultivation & Battle Annals
        </h3>

        <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
          {state.battleLog.length === 0 ? (
            <div className="text-xs text-[#9fb3a4] text-center py-4 italic">
              No battle events recorded yet. Complete a cultivation task to strike!
            </div>
          ) : (
            state.battleLog.map(entry => (
              <div
                key={entry.id}
                className={`text-xs p-2.5 rounded-xl border flex items-start justify-between gap-3 ${
                  entry.kind === 'epic'
                    ? 'bg-[#d4af37]/10 border-[#d4af37]/40 text-[#f7ecc9]'
                    : entry.kind === 'good'
                    ? 'bg-[#2f9e6e]/10 border-[#2f9e6e]/40 text-[#d6f4e3]'
                    : entry.kind === 'bad'
                    ? 'bg-rose-950/20 border-rose-800/40 text-rose-200'
                    : 'bg-[#0a0f0e] border-[#2c4438] text-[#9fb3a4]'
                }`}
              >
                <span className="flex-1 leading-relaxed">{entry.text}</span>
                <span className="text-[10px] text-[#9fb3a4] font-mono shrink-0 opacity-75">
                  {entry.timestamp}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
