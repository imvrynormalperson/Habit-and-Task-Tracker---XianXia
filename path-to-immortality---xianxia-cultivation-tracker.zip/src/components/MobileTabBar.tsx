import React from 'react';
import { Scroll, Swords, Flame, Sparkles, Compass } from 'lucide-react';

export type MainTab = 'quests' | 'demon' | 'alchemy' | 'pavilion' | 'path';

interface MobileTabBarProps {
  activeTab: MainTab;
  onChangeTab: (tab: MainTab) => void;
  demonDefeated?: boolean;
}

export const MobileTabBar: React.FC<MobileTabBarProps> = ({ activeTab, onChangeTab, demonDefeated }) => {
  const tabs = [
    { id: 'quests' as MainTab, label: 'Cultivation', icon: Scroll },
    { id: 'demon' as MainTab, label: 'Inner Demon', icon: Swords, badge: !demonDefeated },
    { id: 'alchemy' as MainTab, label: 'Cauldron', icon: Flame },
    { id: 'pavilion' as MainTab, label: 'Pavilion', icon: Sparkles },
    { id: 'path' as MainTab, label: 'Path', icon: Compass }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0a0f0e]/95 backdrop-blur-lg border-t border-[#2c4438] pb-safe transition-all">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              className="relative flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] text-center select-none cursor-pointer group active:scale-95 transition"
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 group-hover:scale-110 ${
                    isActive ? 'text-[#5fe0a4] stroke-[2.5]' : 'text-[#9fb3a4]'
                  }`}
                />
                {tab.badge && (
                  <span className="absolute -top-1 -right-1.5 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                )}
              </div>
              <span
                className={`text-[10px] font-medium tracking-tight mt-1 truncate transition-colors ${
                  isActive ? 'text-[#5fe0a4] font-bold' : 'text-[#9fb3a4]'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-4 h-0.5 rounded-full bg-[#5fe0a4]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
