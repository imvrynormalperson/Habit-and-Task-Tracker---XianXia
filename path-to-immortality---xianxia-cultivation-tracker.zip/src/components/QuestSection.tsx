import React, { useState } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { Quest, QuestType, QuestDifficulty, QuestCategory } from '../types/cultivation';
import { Plus, Check, Trash2, Flame, ChevronDown, ChevronUp, Sparkles, Filter, X } from 'lucide-react';

export const QuestSection: React.FC = () => {
  const { state, toggleQuest, addQuest, deleteQuest, toggleSubtask } = useCultivation();

  const [activeTab, setActiveTab] = useState<QuestType | 'all'>('daily');
  const [selectedCategory, setSelectedCategory] = useState<QuestCategory>('all');
  const [isAdding, setIsAdding] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<QuestType>('daily');
  const [newDifficulty, setNewDifficulty] = useState<QuestDifficulty>('normal');
  const [newCategory, setNewCategory] = useState<QuestCategory>('mind');
  const [subtaskInputs, setSubtaskInputs] = useState<string[]>(['']);
  const [expandedQuestId, setExpandedQuestId] = useState<string | null>(null);

  // Reward float toast animation
  const [floatNotice, setFloatNotice] = useState<{ id: string; text: string; crit?: boolean } | null>(null);

  const handleToggle = (q: Quest) => {
    const res = toggleQuest(q.id);
    if (!q.done) {
      const text = `${res.crit ? '⚡ CRIT! ' : ''}+${res.xp} Qi · +${res.coins} Stones${res.herbDropped ? ` · 🌿 ${res.herbDropped}` : ''}`;
      setFloatNotice({ id: q.id, text, crit: res.crit });
      setTimeout(() => setFloatNotice(null), 1800);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const validSubtasks = subtaskInputs.filter(s => s.trim().length > 0);
    addQuest(newTitle, newType, newDifficulty, newCategory, validSubtasks);

    setNewTitle('');
    setSubtaskInputs(['']);
    setIsAdding(false);
  };

  const addSubtaskField = () => {
    setSubtaskInputs(prev => [...prev, '']);
  };

  const updateSubtaskField = (index: number, val: string) => {
    setSubtaskInputs(prev => {
      const updated = [...prev];
      updated[index] = val;
      return updated;
    });
  };

  const removeSubtaskField = (index: number) => {
    setSubtaskInputs(prev => prev.filter((_, i) => i !== index));
  };

  // Filtered list
  const filteredQuests = state.quests.filter(q => {
    if (activeTab !== 'all' && q.type !== activeTab) return false;
    if (selectedCategory !== 'all' && q.category !== selectedCategory) return false;
    return true;
  });

  const dailyCount = state.quests.filter(q => q.type === 'daily').length;
  const dailyDoneCount = state.quests.filter(q => q.type === 'daily' && q.done).length;

  return (
    <div className="w-full space-y-4">
      {/* Top Controls: Tabs & Category Filter */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        {/* Segmented Tab Controls */}
        <div className="flex items-center p-1 bg-[#131f1c] border border-[#2c4438] rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('daily')}
            className={`flex-1 sm:flex-none px-3.5 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'daily'
                ? 'bg-[#2f9e6e] text-[#08120e] shadow-sm font-bold'
                : 'text-[#9fb3a4] hover:text-[#f2ead2]'
            }`}
          >
            <span>Daily Cultivation</span>
            <span className="text-[10px] font-mono opacity-80">({dailyDoneCount}/{dailyCount})</span>
          </button>

          <button
            onClick={() => setActiveTab('side')}
            className={`flex-1 sm:flex-none px-3.5 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'side'
                ? 'bg-[#d4af37] text-[#08120e] shadow-sm font-bold'
                : 'text-[#9fb3a4] hover:text-[#f2ead2]'
            }`}
          >
            <span>Side Quests</span>
            <span className="text-[10px] font-mono opacity-80">
              ({state.quests.filter(q => q.type === 'side').length})
            </span>
          </button>

          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-2 rounded-lg transition cursor-pointer ${
              activeTab === 'all'
                ? 'bg-[#1c2b26] text-[#f2ead2] font-bold border border-[#2c4438]'
                : 'text-[#9fb3a4] hover:text-[#f2ead2]'
            }`}
          >
            All
          </button>
        </div>

        {/* Add Quest Trigger */}
        <button
          onClick={() => {
            setNewType(activeTab === 'side' ? 'side' : 'daily');
            setIsAdding(true);
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#2f9e6e] to-[#5fe0a4] text-[#08120e] font-cinzel font-bold text-xs shadow-md shadow-[#2f9e6e]/20 hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Task</span>
        </button>
      </div>

      {/* Category Filter Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs text-[#9fb3a4]">
        <Filter className="w-3.5 h-3.5 text-[#5fe0a4] shrink-0 mr-1" />
        {(['all', 'mind', 'body', 'craft', 'spirit'] as QuestCategory[]).map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-2.5 py-1 rounded-lg border text-xs capitalize transition cursor-pointer whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-[#1c2b26] border-[#5fe0a4] text-[#5fe0a4] font-semibold'
                : 'bg-[#131f1c] border-[#2c4438] text-[#9fb3a4] hover:border-[#9fb3a4]'
            }`}
          >
            {cat === 'all' ? 'All Realms' : cat}
          </button>
        ))}
      </div>

      {/* Add Task Modal / Drawer Form */}
      {isAdding && (
        <div className="p-4 sm:p-5 rounded-2xl bg-[#131f1c] border-2 border-[#5fe0a4]/50 shadow-2xl relative animate-in fade-in duration-200">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-cinzel font-bold text-sm text-[#f2ead2] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#5fe0a4]" />
              Inscribe Cultivation Task
            </h3>
            <button
              onClick={() => setIsAdding(false)}
              className="text-[#9fb3a4] hover:text-[#f2ead2] p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleAddSubmit} className="space-y-3">
            <div>
              <input
                type="text"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                placeholder="E.g., 45 minutes coding, morning sprint, read scripture..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2] placeholder-[#9fb3a4]/50 text-sm focus:outline-hidden focus:border-[#5fe0a4]"
                autoFocus
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Type */}
              <div>
                <label className="block text-[11px] text-[#9fb3a4] mb-1">Quest Type</label>
                <select
                  value={newType}
                  onChange={e => setNewType(e.target.value as QuestType)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2] text-xs"
                >
                  <option value="daily">Daily Cultivation (Repeats)</option>
                  <option value="side">Side Quest (One-off)</option>
                </select>
              </div>

              {/* Difficulty */}
              <div>
                <label className="block text-[11px] text-[#9fb3a4] mb-1">Difficulty</label>
                <select
                  value={newDifficulty}
                  onChange={e => setNewDifficulty(e.target.value as QuestDifficulty)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2] text-xs"
                >
                  <option value="easy">Easy (+12 Qi, +6 Stones)</option>
                  <option value="normal">Normal (+20 Qi, +12 Stones)</option>
                  <option value="hard">Hard (+35 Qi, +20 Stones)</option>
                  <option value="tribulation">Tribulation (+55 Qi, +35 Stones)</option>
                </select>
              </div>

              {/* Category */}
              <div>
                <label className="block text-[11px] text-[#9fb3a4] mb-1">Category (Herb Affinity)</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as QuestCategory)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2] text-xs capitalize"
                >
                  <option value="mind">Mind (Ginseng Drop)</option>
                  <option value="body">Body (Dragon Grass Drop)</option>
                  <option value="craft">Craft (Celestial Dew Drop)</option>
                  <option value="spirit">Spirit (Nether Lotus Drop)</option>
                </select>
              </div>
            </div>

            {/* Optional Subtasks */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-[11px] text-[#9fb3a4]">Subtask Milestones (Optional)</span>
                <button
                  type="button"
                  onClick={addSubtaskField}
                  className="text-[11px] text-[#5fe0a4] hover:underline cursor-pointer"
                >
                  + Add Step
                </button>
              </div>
              <div className="space-y-1.5">
                {subtaskInputs.map((st, i) => (
                  <div key={i} className="flex gap-2">
                    <input
                      type="text"
                      value={st}
                      onChange={e => updateSubtaskField(i, e.target.value)}
                      placeholder={`Step ${i + 1}`}
                      className="flex-1 px-3 py-1.5 rounded-lg bg-[#0a0f0e] border border-[#2c4438] text-xs text-[#f2ead2]"
                    />
                    {subtaskInputs.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeSubtaskField(i)}
                        className="px-2 text-rose-400 hover:text-rose-300 text-xs"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-3 py-2 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[#9fb3a4] text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-[#2f9e6e] hover:bg-[#5fe0a4] text-[#08120e] font-cinzel font-bold text-xs shadow transition cursor-pointer"
              >
                Inscribe Task
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Quest List */}
      <div className="space-y-2.5">
        {filteredQuests.length === 0 ? (
          <div className="p-8 text-center bg-[#131f1c] border border-dashed border-[#2c4438] rounded-2xl">
            <Sparkles className="w-8 h-8 text-[#5fe0a4]/40 mx-auto mb-2" />
            <div className="font-cinzel text-sm text-[#f2ead2] mb-1">
              No cultivation tasks in this realm
            </div>
            <p className="text-xs text-[#9fb3a4] max-w-sm mx-auto mb-4">
              Add your daily spiritual habits or focused craft tasks to begin harvesting Qi and subduing the inner demon!
            </p>
            <button
              onClick={() => setIsAdding(true)}
              className="px-4 py-2 rounded-xl bg-[#2f9e6e] text-[#08120e] font-semibold text-xs transition cursor-pointer"
            >
              + Create First Task
            </button>
          </div>
        ) : (
          filteredQuests.map(quest => {
            const hasSubtasks = quest.subtasks && quest.subtasks.length > 0;
            const completedSubCount = quest.subtasks?.filter(s => s.completed).length || 0;
            const isExpanded = expandedQuestId === quest.id;

            return (
              <div
                key={quest.id}
                className={`group relative bg-[#131f1c] border transition-all rounded-2xl p-3.5 sm:p-4 shadow-sm ${
                  quest.done
                    ? 'border-[#2c4438]/50 opacity-65 bg-[#0e1614]'
                    : quest.type === 'side'
                    ? 'border-[#d4af37]/40 hover:border-[#d4af37]'
                    : 'border-[#2c4438] hover:border-[#5fe0a4]/60'
                }`}
              >
                {/* Floating Reward Notification */}
                {floatNotice && floatNotice.id === quest.id && (
                  <div className="absolute top-2 right-4 z-20 pointer-events-none animate-bounce">
                    <div className="bg-[#2f9e6e] text-[#08120e] font-mono text-[11px] font-bold px-2.5 py-1 rounded-lg shadow-lg">
                      {floatNotice.text}
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-3">
                  {/* Seal Checkbox (44x44px touch area) */}
                  <button
                    onClick={() => handleToggle(quest)}
                    aria-label={`Mark ${quest.title} as ${quest.done ? 'incomplete' : 'complete'}`}
                    className={`min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center border-2 transition-all cursor-pointer ${
                      quest.done
                        ? 'bg-[#2f9e6e] border-[#5fe0a4] text-[#08120e] shadow-md shadow-[#2f9e6e]/30'
                        : 'bg-[#0a0f0e] border-[#2c4438] text-transparent hover:border-[#5fe0a4]'
                    }`}
                  >
                    <Check className={`w-5 h-5 stroke-[3] ${quest.done ? 'opacity-100' : 'opacity-0'}`} />
                  </button>

                  {/* Quest Title & Unboxed Metadata */}
                  <div className="flex-1 min-w-0 pt-0.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h4
                          className={`text-sm sm:text-base font-medium text-[#f2ead2] leading-snug transition ${
                            quest.done ? 'line-through text-[#9fb3a4]' : ''
                          }`}
                        >
                          {quest.title}
                        </h4>

                        {/* Unboxed Metadata Discipline */}
                        <div className="flex items-center flex-wrap gap-2 text-xs text-[#9fb3a4] mt-1">
                          <span className="capitalize text-[#5fe0a4] font-medium">{quest.category}</span>
                          <span aria-hidden="true" className="opacity-40">·</span>
                          <span className="capitalize">{quest.difficulty}</span>
                          {quest.type === 'daily' && quest.streak !== undefined && quest.streak > 0 && (
                            <>
                              <span aria-hidden="true" className="opacity-40">·</span>
                              <span className="text-amber-400 font-mono flex items-center gap-0.5">
                                <Flame className="w-3 h-3 text-amber-500" />
                                {quest.streak}d streak
                              </span>
                            </>
                          )}
                          {hasSubtasks && (
                            <>
                              <span aria-hidden="true" className="opacity-40">·</span>
                              <span className="text-[11px] font-mono">
                                {completedSubCount}/{quest.subtasks!.length} steps
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        {hasSubtasks && (
                          <button
                            onClick={() => setExpandedQuestId(isExpanded ? null : quest.id)}
                            className="p-1.5 rounded-lg text-[#9fb3a4] hover:text-[#f2ead2] hover:bg-[#1c2b26] transition cursor-pointer"
                            title="Toggle subtasks"
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        )}

                        <button
                          onClick={() => deleteQuest(quest.id)}
                          className="p-1.5 rounded-lg text-[#9fb3a4]/60 hover:text-rose-400 hover:bg-[#1c2b26] transition cursor-pointer"
                          title="Dissolve task"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Expandable Subtasks Checklist */}
                    {hasSubtasks && isExpanded && (
                      <div className="mt-3 pt-3 border-t border-[#2c4438]/70 space-y-1.5">
                        {quest.subtasks!.map(st => (
                          <div
                            key={st.id}
                            onClick={() => toggleSubtask(quest.id, st.id)}
                            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-[#0a0f0e]/50 text-xs text-[#f2ead2] cursor-pointer"
                          >
                            <div
                              className={`w-4 h-4 rounded-md border flex items-center justify-center transition ${
                                st.completed ? 'bg-[#2f9e6e] border-[#5fe0a4] text-[#08120e]' : 'border-[#2c4438]'
                              }`}
                            >
                              {st.completed && <Check className="w-3 h-3 stroke-[3]" />}
                            </div>
                            <span className={st.completed ? 'line-through text-[#9fb3a4]' : ''}>
                              {st.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
