import React from 'react';
import { X, BookOpen, Shield, Swords, Sparkles, Flame, Zap } from 'lucide-react';

interface CultivationGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CultivationGuideModal: React.FC<CultivationGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg max-h-[85vh] overflow-y-auto rounded-2xl bg-[#131f1c] border border-[#2c4438] p-5 sm:p-6 shadow-2xl text-left">
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-4 right-4 text-[#9fb3a4] hover:text-[#f2ead2] p-1 rounded-lg hover:bg-[#1c2b26] transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <BookOpen className="w-5 h-5 text-[#5fe0a4]" />
          <h2 className="font-cinzel font-bold text-lg text-[#f2ead2]">
            Supreme Cultivation Manual
          </h2>
        </div>
        <p className="text-xs text-[#9fb3a4] mb-5">
          Read the ancient secrets of maintaining your Dao Heart and attaining immortality.
        </p>

        <div className="space-y-4 text-xs text-[#9fb3a4] leading-relaxed">
          {/* Chapter 1 */}
          <div className="p-3.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438]">
            <h3 className="font-cinzel font-bold text-xs text-[#5fe0a4] mb-1 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#5fe0a4]" />
              01. The Daily Cultivation Cycle
            </h3>
            <p>
              Daily tasks represent your persistent spiritual discipline. Complete them before midnight to harvest <strong className="text-[#f2ead2]">Spiritual Qi</strong>, earn <strong className="text-[#5fe0a4]">Spirit Stones</strong>, and extend your daily streak. Each task completed also unleashes a Sword Qi strike against today’s Inner Demon!
            </p>
          </div>

          {/* Chapter 2 */}
          <div className="p-3.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438]">
            <h3 className="font-cinzel font-bold text-xs text-rose-400 mb-1 flex items-center gap-1.5">
              <Swords className="w-3.5 h-3.5 text-rose-400" />
              02. Inner Demons & Backlash
            </h3>
            <p>
              Every midnight, yesterday's incomplete daily tasks trigger demonic backlash. Missing tasks inflicts Dao Heart damage and breaks your streak. You can protect yourself with:
            </p>
            <ul className="list-disc list-inside mt-1.5 space-y-1 text-[#f2ead2]">
              <li><strong className="text-[#5fe0a4]">Heart Shield Pill:</strong> Absorbs demon attacks, preventing Dao Heart loss.</li>
              <li><strong className="text-sky-400">Streak Freeze Pill:</strong> Preserves your streak even if tasks are skipped for a day.</li>
            </ul>
          </div>

          {/* Chapter 3 */}
          <div className="p-3.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438]">
            <h3 className="font-cinzel font-bold text-xs text-[#d4af37] mb-1 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-[#d4af37]" />
              03. Heavenly Tribulation Breakthroughs
            </h3>
            <p>
              When your Spiritual Qi bar fills to 100%, you can face the <strong className="text-[#f2ead2]">Heavenly Tribulation</strong>. Passing the lightning trial ascends you to the next cultivation level, completely restores your Dao Heart to 100%, and increases your permanent maximum health!
            </p>
          </div>

          {/* Chapter 4 */}
          <div className="p-3.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438]">
            <h3 className="font-cinzel font-bold text-xs text-emerald-400 mb-1 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-emerald-400" />
              04. Alchemy & Spiritual Herbs
            </h3>
            <p>
              Completing tasks rewards rare spiritual herbs based on their category:
            </p>
            <div className="grid grid-cols-2 gap-2 mt-2 font-mono text-[11px]">
              <div className="bg-[#131f1c] p-1.5 rounded border border-[#2c4438]">🌿 Mind → Spirit Ginseng</div>
              <div className="bg-[#131f1c] p-1.5 rounded border border-[#2c4438]">🐉 Body → Dragon Grass</div>
              <div className="bg-[#131f1c] p-1.5 rounded border border-[#2c4438]">🪷 Spirit → Nether Lotus</div>
              <div className="bg-[#131f1c] p-1.5 rounded border border-[#2c4438]">💎 Bosses → Celestial Dew</div>
            </div>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-[#2c4438] text-right">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-[#2f9e6e] text-[#08120e] font-cinzel font-bold text-xs hover:bg-[#5fe0a4] transition cursor-pointer"
          >
            I Understand the Dao
          </button>
        </div>
      </div>
    </div>
  );
};
