import React, { useState } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { X, Copy, Check, Download, AlertTriangle, ShieldCheck, Smartphone } from 'lucide-react';

interface DaoScrollModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DaoScrollModal: React.FC<DaoScrollModalProps> = ({ isOpen, onClose }) => {
  const { exportBackupCode, importBackupCode, resetAllProgress } = useCultivation();
  const { isInstallable, isInstalled, install } = usePWAInstall();

  const [backupCode, setBackupCode] = useState('');
  const [importInput, setImportInput] = useState('');
  const [copied, setCopied] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; good: boolean } | null>(null);

  if (!isOpen) return null;

  const handleGenerateCode = () => {
    const code = exportBackupCode();
    setBackupCode(code);
  };

  const handleCopy = async () => {
    if (!backupCode) return;
    try {
      await navigator.clipboard.writeText(backupCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleRestore = () => {
    if (!importInput.trim()) return;
    if (window.confirm('Restore this cultivation scroll? Your current progress on this device will be replaced.')) {
      const ok = importBackupCode(importInput);
      if (ok) {
        setStatusMessage({ text: 'Cultivation scroll restored successfully!', good: true });
        setImportInput('');
      } else {
        setStatusMessage({ text: 'Invalid scroll code. Please check and try again.', good: false });
      }
    }
  };

  const handleReset = () => {
    if (window.confirm('Reset ALL cultivation progress on this device? This cannot be undone without a backup code.')) {
      resetAllProgress();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-[#131f1c] border border-[#2c4438] p-5 sm:p-6 shadow-2xl text-left">
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-4 right-4 text-[#9fb3a4] hover:text-[#f2ead2] p-1 rounded-lg hover:bg-[#1c2b26] transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <Smartphone className="w-5 h-5 text-[#5fe0a4]" />
          <h2 className="font-cinzel font-bold text-lg text-[#f2ead2]">
            Cultivation Scroll & Android App
          </h2>
        </div>
        <p className="text-xs text-[#9fb3a4] mb-5">
          Manage your progress record, install the native Android/PWA experience, and safeguard your Dao path.
        </p>

        {/* Android PWA Install Section */}
        <div className="p-4 rounded-xl bg-[#0a0f0e] border border-[#2c4438] mb-5">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div>
              <h3 className="font-cinzel font-bold text-xs sm:text-sm text-[#f2ead2] flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-[#5fe0a4]" />
                Android Application Experience
              </h3>
              <p className="text-xs text-[#9fb3a4] mt-0.5">
                {isInstalled
                  ? 'App is running in Standalone Android App mode!'
                  : 'Install onto your home screen for full offline support, fast launch, and haptic feedback.'}
              </p>
            </div>

            {!isInstalled && isInstallable && (
              <button
                onClick={install}
                className="px-3.5 py-1.5 rounded-lg bg-[#2f9e6e] hover:bg-[#5fe0a4] text-[#08120e] font-semibold text-xs transition active:scale-95 cursor-pointer shrink-0"
              >
                Install App
              </button>
            )}
          </div>

          <div className="text-[11px] text-[#9fb3a4] space-y-1 pt-2 border-t border-[#2c4438]/50">
            <div>• <strong className="text-[#f2ead2]">Chrome for Android:</strong> Tap the prompt or browser menu (⋮) → "Install app" / "Add to Home screen".</div>
            <div>• <strong className="text-[#f2ead2]">Samsung Internet:</strong> Tap Menu (☰) → "Add page to" → "App screen" or "Home screen".</div>
            <div>• <strong className="text-[#f2ead2]">Offline Storage:</strong> All quests, pills, and progress are stored safely on your device.</div>
          </div>
        </div>

        {/* Status Message */}
        {statusMessage && (
          <div
            className={`p-3 rounded-xl text-xs mb-4 flex items-center gap-2 ${
              statusMessage.good
                ? 'bg-[#2f9e6e]/20 border border-[#5fe0a4] text-[#5fe0a4]'
                : 'bg-rose-950/30 border border-rose-500 text-rose-300'
            }`}
          >
            {statusMessage.good ? <ShieldCheck className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Export Backup Code */}
        <div className="space-y-2 mb-5">
          <div className="flex justify-between items-center">
            <span className="font-cinzel text-xs font-bold text-[#f2ead2]">Generate Backup Code</span>
            <div className="flex gap-2">
              <button
                onClick={handleGenerateCode}
                className="px-3 py-1 rounded-lg bg-[#1c2b26] hover:bg-[#2c4438] text-xs text-[#f2ead2] transition cursor-pointer"
              >
                Generate Code
              </button>
              {backupCode && (
                <button
                  onClick={handleCopy}
                  className="px-3 py-1 rounded-lg bg-[#2f9e6e] text-[#08120e] text-xs font-semibold hover:bg-[#5fe0a4] transition flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
              )}
            </div>
          </div>

          <textarea
            readOnly
            value={backupCode}
            placeholder="Click 'Generate Code' above to view your progress export string."
            className="w-full h-20 p-2.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[11px] font-mono text-[#9fb3a4] resize-none focus:outline-hidden"
          />
        </div>

        {/* Restore Backup Code */}
        <div className="space-y-2 mb-6">
          <span className="font-cinzel text-xs font-bold text-[#f2ead2]">Restore from Backup Code</span>
          <textarea
            value={importInput}
            onChange={e => setImportInput(e.target.value)}
            placeholder="Paste your backup code string here, then click Restore below..."
            className="w-full h-20 p-2.5 rounded-xl bg-[#0a0f0e] border border-[#2c4438] text-[11px] font-mono text-[#f2ead2] resize-none focus:outline-hidden focus:border-[#5fe0a4]"
          />
          <button
            onClick={handleRestore}
            disabled={!importInput.trim()}
            className="w-full py-2.5 rounded-xl bg-[#d4af37] text-[#0a0f0e] font-cinzel font-bold text-xs hover:brightness-110 active:scale-98 transition disabled:opacity-40 cursor-pointer"
          >
            Restore Progress
          </button>
        </div>

        {/* Danger Zone: Reset */}
        <div className="pt-4 border-t border-[#2c4438] flex items-center justify-between text-xs">
          <div>
            <div className="text-rose-400 font-semibold">Sever All Mortal Ties</div>
            <div className="text-[11px] text-[#9fb3a4]">Wipe all local cultivation data</div>
          </div>
          <button
            onClick={handleReset}
            className="px-3.5 py-1.5 rounded-xl border border-rose-800 text-rose-400 hover:bg-rose-950/40 text-xs transition cursor-pointer"
          >
            Reset Progress
          </button>
        </div>
      </div>
    </div>
  );
};
