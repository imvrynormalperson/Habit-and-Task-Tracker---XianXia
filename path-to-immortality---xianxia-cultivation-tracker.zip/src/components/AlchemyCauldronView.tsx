import React, { useState } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { PILL_RECIPES } from '../data/cultivationData';
import { PillRecipe, HerbInventory } from '../types/cultivation';
import { Flame, Sparkles, Shield, Snowflake, HeartPulse, Check } from 'lucide-react';
import cauldronImg from '../assets/images/alchemy_furnace_1790168746074.jpg';

export const AlchemyCauldronView: React.FC = () => {
  const { state, concoctPill } = useCultivation();
  const [brewingPillId, setBrewingPillId] = useState<string | null>(null);

  const herbs = state.herbs;

  const canBrew = (recipe: PillRecipe) => {
    if (state.coins < recipe.costStones) return false;
    for (const [herb, count] of Object.entries(recipe.ingredients)) {
      if ((herbs[herb as keyof HerbInventory] || 0) < (count || 0)) {
        return false;
      }
    }
    return true;
  };

  const handleBrew = (recipe: PillRecipe) => {
    if (!canBrew(recipe)) return;
    setBrewingPillId(recipe.id);
    setTimeout(() => {
      concoctPill(recipe);
      setBrewingPillId(null);
    }, 700);
  };

  return (
    <div className="w-full space-y-5">
      {/* Cauldron Banner */}
      <div className="relative w-full rounded-2xl overflow-hidden bg-[#131f1c] border border-[#2c4438] shadow-2xl">
        <div className="relative h-44 sm:h-52 w-full overflow-hidden bg-[#0a0f0e]">
          <img
            src={cauldronImg}
            alt="Mystical Alchemy Cauldron"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center brightness-85 contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131f1c] via-[#131f1c]/40 to-transparent" />

          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#5fe0a4] font-cinzel font-semibold mb-0.5">
                <Flame className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Nine Dragons Spirit Cauldron</span>
              </div>
              <h2 className="font-cinzel font-bold text-lg sm:text-xl text-[#f2ead2]">
                Alchemy Cauldron Pavilion
              </h2>
            </div>
            <div className="text-right">
              <span className="text-[11px] text-[#9fb3a4] block">Pills Refined</span>
              <span className="font-mono text-base font-bold text-[#5fe0a4] tabular-nums">
                {state.stats.pillsRefined}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Spiritual Herbs Inventory Bar */}
      <div>
        <h3 className="font-cinzel text-xs font-bold text-[#9fb3a4] mb-2 uppercase tracking-wider">
          Spiritual Herb Storehouse
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Ginseng */}
          <div className="p-3 rounded-xl bg-[#131f1c] border border-[#2c4438] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">🌿</span>
              <div>
                <div className="text-xs font-medium text-[#f2ead2]">Spirit Ginseng</div>
                <div className="text-[10px] text-[#9fb3a4]">From Mind Tasks</div>
              </div>
            </div>
            <span className="font-mono text-base font-bold text-[#5fe0a4] tabular-nums">
              {herbs.ginseng}
            </span>
          </div>

          {/* Dragon Grass */}
          <div className="p-3 rounded-xl bg-[#131f1c] border border-[#2c4438] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">🐉</span>
              <div>
                <div className="text-xs font-medium text-[#f2ead2]">Dragon Grass</div>
                <div className="text-[10px] text-[#9fb3a4]">From Body Tasks</div>
              </div>
            </div>
            <span className="font-mono text-base font-bold text-[#5fe0a4] tabular-nums">
              {herbs.dragonGrass}
            </span>
          </div>

          {/* Nether Lotus */}
          <div className="p-3 rounded-xl bg-[#131f1c] border border-[#2c4438] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">🪷</span>
              <div>
                <div className="text-xs font-medium text-[#f2ead2]">Nether Lotus</div>
                <div className="text-[10px] text-[#9fb3a4]">From Spirit Tasks</div>
              </div>
            </div>
            <span className="font-mono text-base font-bold text-[#5fe0a4] tabular-nums">
              {herbs.netherLotus}
            </span>
          </div>

          {/* Celestial Dew */}
          <div className="p-3 rounded-xl bg-[#131f1c] border border-[#2c4438] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">💎</span>
              <div>
                <div className="text-xs font-medium text-[#f2ead2]">Celestial Dew</div>
                <div className="text-[10px] text-[#9fb3a4]">Bosses & Streaks</div>
              </div>
            </div>
            <span className="font-mono text-base font-bold text-purple-400 tabular-nums">
              {herbs.celestialDew}
            </span>
          </div>
        </div>
      </div>

      {/* Pill Concoction Grid */}
      <div>
        <h3 className="font-cinzel text-xs font-bold text-[#9fb3a4] mb-3 uppercase tracking-wider">
          Ancient Pill Formulas
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {PILL_RECIPES.map(recipe => {
            const affordable = canBrew(recipe);
            const isBrewing = brewingPillId === recipe.id;

            return (
              <div
                key={recipe.id}
                className="bg-[#131f1c] border border-[#2c4438] hover:border-[#5fe0a4]/50 rounded-2xl p-4 flex flex-col justify-between transition-all shadow-sm"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <h4 className="font-cinzel font-bold text-sm text-[#f2ead2] flex items-center gap-1.5">
                        {recipe.type === 'shield' && <Shield className="w-4 h-4 text-[#5fe0a4]" />}
                        {recipe.type === 'freeze' && <Snowflake className="w-4 h-4 text-sky-400" />}
                        {recipe.type === 'heal' && <HeartPulse className="w-4 h-4 text-rose-400" />}
                        {recipe.type === 'elixir' && <Sparkles className="w-4 h-4 text-[#d4af37]" />}
                        <span>{recipe.name}</span>
                      </h4>
                      <div className="text-[11px] text-[#5fe0a4] font-cinzel">
                        {recipe.chineseName}
                      </div>
                    </div>
                    <span className="font-mono text-xs text-[#d4af37] font-semibold shrink-0">
                      {recipe.costStones} Stones
                    </span>
                  </div>

                  <p className="text-xs text-[#9fb3a4] leading-relaxed mb-3">
                    {recipe.description}
                  </p>

                  {/* Required Ingredients */}
                  <div className="flex items-center flex-wrap gap-2 text-[11px] mb-4">
                    <span className="text-[#9fb3a4]">Requires:</span>
                    {Object.entries(recipe.ingredients).map(([herb, count]) => {
                      const available = herbs[herb as keyof HerbInventory] || 0;
                      const hasEnough = available >= (count || 0);

                      const labels: Record<string, string> = {
                        ginseng: 'Ginseng',
                        dragonGrass: 'Dragon Grass',
                        netherLotus: 'Lotus',
                        celestialDew: 'Dew'
                      };

                      return (
                        <span
                          key={herb}
                          className={`font-mono ${hasEnough ? 'text-[#5fe0a4]' : 'text-rose-400 font-semibold'}`}
                        >
                          {labels[herb] || herb}: {available}/{count}
                        </span>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#2c4438]/50">
                  <span className="text-[11px] text-[#d4af37] font-medium">
                    {recipe.effectDescription}
                  </span>

                  <button
                    onClick={() => handleBrew(recipe)}
                    disabled={!affordable || isBrewing}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#2f9e6e] to-[#5fe0a4] text-[#08120e] font-cinzel font-bold text-xs hover:brightness-110 active:scale-95 transition disabled:opacity-40 flex items-center gap-1.5 cursor-pointer"
                  >
                    {isBrewing ? (
                      <>
                        <Flame className="w-3.5 h-3.5 animate-spin" />
                        <span>Refining...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Refine Pill</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
