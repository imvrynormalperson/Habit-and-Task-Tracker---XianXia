import React, { useState, useEffect } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { ROBE_SKINS, MENTOR_QUOTES } from '../data/cultivationData';
import { Sparkles, Shield, Snowflake, Flame, Gem, RefreshCw, AlertTriangle, Swords } from 'lucide-react';

interface CultivatorHUDProps {
  onOpenBreakthrough: () => void;
  onNavigateToDemon: () => void;
}

export const CultivatorHUD: React.FC<CultivatorHUDProps> = ({ onOpenBreakthrough, onNavigateToDemon }) => {
  const { state, currentRealm, qiNeeded, readyForBreakthrough } = useCultivation();
  const [mentorIndex, setMentorIndex] = useState(0);

  // Dynamic mentor advice based on progress
  const activeSkin = ROBE_SKINS.find(s => s.id === state.activeSkin) || ROBE_SKINS[0];

  const qiPercentage = Math.min(100, Math.round((state.xp / qiNeeded) * 100));
  const hpPercentage = Math.max(0, Math.min(100, Math.round((state.hp / state.maxHp) * 100)));

  // Auto pick contextual quote or rotate
  useEffect(() => {
    const hour = new Date().getHours();
    if (state.hp <= 30) {
      setMentorIndex(3); // Warning on wavering Dao heart
    } else if (hour >= 18) {
      setMentorIndex(4); // Evening reminder
    } else {
      setMentorIndex(Math.floor(Math.random() * MENTOR_QUOTES.length));
    }
  }, [state.hp]);

  const cycleMentor = () => {
    setMentorIndex((prev) => (prev + 1) % MENTOR_QUOTES.length);
  };

  const currentMentor = MENTOR_QUOTES[mentorIndex];

  return (
    <div className="w-full bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4 sm:p-5 shadow-xl relative overflow-hidden mb-4">
      {/* Background Spiritual Aura Gradients */}
      <div className="absolute -top-24 -right-24 w-60 h-60 bg-[#2f9e6e]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main HUD Row */}
      <div className="flex flex-col md:flex-row gap-4 sm:gap-6 relative z-10">
        {/* Left: Avatar & Robe Identity */}
        <div className="flex items-center md:flex-col justify-start md:justify-center gap-3 shrink-0">
          <div className="relative group">
            <div className={`w-18 h-18 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-[#1c2b26] to-[#0a0f0e] border-2 ${readyForBreakthrough ? 'border-[#d4af37] shadow-lg shadow-[#d4af37]/30 animate-pulse' : 'border-[#2f9e6e]'} flex items-center justify-center text-3xl sm:text-4xl shadow-inner select-none transition-transform group-hover:scale-105`}>
              {activeSkin.emoji}
            </div>
            <div className="absolute -bottom-2 -right-1 bg-gradient-to-r from-[#2f9e6e] to-[#5fe0a4] text-[#08120e] font-cinzel font-black text-xs px-2 py-0.5 rounded-full border border-[#0a0f0e] shadow">
              Lv.{state.level}
            </div>
          </div>

          <div className="text-left md:text-center min-w-0">
            <div className="font-cinzel font-bold text-sm sm:text-base text-[#f2ead2] truncate">
              {activeSkin.name}
            </div>
            <div className="text-xs text-[#5fe0a4] font-medium truncate">
              {currentRealm.chineseName} · {currentRealm.name}
            </div>
          </div>
        </div>

        {/* Center & Right: Progress Bars & Stats */}
        <div className="flex-1 flex flex-col justify-between gap-3 min-w-0">
          {/* Qi Bar */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="font-cinzel font-semibold text-[#5fe0a4] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#5fe0a4]" />
                Spiritual Qi
                {state.qiBoostCharges > 0 && (
                  <span className="text-[10px] text-[#d4af37] bg-[#d4af37]/15 px-1.5 py-0.2 rounded-md font-mono">
                    2x Qi ({state.qiBoostCharges} left)
                  </span>
                )}
              </span>
              <span className="font-mono text-[#9fb3a4] tabular-nums">
                {state.xp} / {qiNeeded} ({qiPercentage}%)
              </span>
            </div>
            <div className="h-3 w-full bg-[#0a0f0e] rounded-full border border-[#2c4438] overflow-hidden p-0.5 relative">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  readyForBreakthrough
                    ? 'bg-gradient-to-r from-[#5fe0a4] via-[#d4af37] to-[#facc15] animate-pulse'
                    : 'bg-gradient-to-r from-[#2f9e6e] to-[#5fe0a4]'
                }`}
                style={{ width: `${qiPercentage}%` }}
              />
            </div>
          </div>

          {/* Dao Heart (HP) Bar */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="font-cinzel font-semibold text-[#f2ead2] flex items-center gap-1.5">
                {hpPercentage <= 25 ? (
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-500 animate-bounce" />
                ) : (
                  <Shield className="w-3.5 h-3.5 text-[#d4af37]" />
                )}
                Dao Heart Foundation
              </span>
              <span className={`font-mono tabular-nums ${hpPercentage <= 25 ? 'text-rose-400 font-bold' : 'text-[#9fb3a4]'}`}>
                {state.hp} / {state.maxHp}
              </span>
            </div>
            <div className="h-2.5 w-full bg-[#0a0f0e] rounded-full border border-[#2c4438] overflow-hidden p-0.5">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  hpPercentage <= 25
                    ? 'bg-gradient-to-r from-rose-600 to-rose-400 animate-pulse'
                    : hpPercentage <= 50
                    ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                    : 'bg-gradient-to-r from-[#d4af37] to-[#f3d97a]'
                }`}
                style={{ width: `${hpPercentage}%` }}
              />
            </div>
          </div>

          {/* Stats Badges */}
          <div className="flex items-center flex-wrap gap-2 pt-1 text-xs">
            {/* Spirit Stones */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2]">
              <span className="w-3.5 h-3.5 rounded-full bg-[#5fe0a4] text-[#08120e] flex items-center justify-center font-serif text-[10px] font-bold">
                S
              </span>
              <span className="font-mono font-bold text-[#5fe0a4] tabular-nums">{state.coins}</span>
              <span className="text-[11px] text-[#9fb3a4]">Stones</span>
            </div>

            {/* Streak */}
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2]">
              <Flame className="w-3.5 h-3.5 text-amber-500" />
              <span className="font-mono font-bold text-amber-400 tabular-nums">{state.streak}</span>
              <span className="text-[11px] text-[#9fb3a4]">day streak</span>
            </div>

            {/* Heart Shields */}
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2]" title="Blocks demonic backlash if tasks are missed">
              <Shield className="w-3.5 h-3.5 text-[#5fe0a4]" />
              <span className="font-mono font-bold text-[#5fe0a4] tabular-nums">{state.shieldCharges}</span>
              <span className="text-[11px] text-[#9fb3a4]">Shields</span>
            </div>

            {/* Streak Freezes */}
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2]" title="Saves streak if a day is missed">
              <Snowflake className="w-3.5 h-3.5 text-sky-400" />
              <span className="font-mono font-bold text-sky-300 tabular-nums">{state.freezeCharges}</span>
              <span className="text-[11px] text-[#9fb3a4]">Freezes</span>
            </div>

            {/* Celestial Dew */}
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0a0f0e] border border-[#2c4438] text-[#f2ead2]" title="Rare essence used for grand alchemy">
              <Gem className="w-3.5 h-3.5 text-purple-400" />
              <span className="font-mono font-bold text-purple-300 tabular-nums">{state.herbs.celestialDew}</span>
              <span className="text-[11px] text-[#9fb3a4]">Dew</span>
            </div>
          </div>
        </div>
      </div>

      {/* Breakthrough Trigger Banner (When Qi reaches 100%) */}
      {readyForBreakthrough && (
        <div className="mt-4 p-3 rounded-xl bg-gradient-to-r from-[#d4af37]/20 via-[#eab308]/15 to-[#2f9e6e]/20 border border-[#d4af37] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#d4af37] animate-spin" />
            <div>
              <div className="font-cinzel font-bold text-xs sm:text-sm text-[#facc15]">
                Heavenly Tribulation Awaits
              </div>
              <div className="text-[11px] text-[#f2ead2]/80">
                Spiritual Qi is overflowing. Undergo the breakthrough rite!
              </div>
            </div>
          </div>
          <button
            onClick={onOpenBreakthrough}
            className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#d4af37] to-[#f59e0b] text-[#0a0f0e] font-cinzel font-bold text-xs hover:brightness-110 active:scale-95 transition shadow cursor-pointer shrink-0"
          >
            Ascend Now
          </button>
        </div>
      )}

      {/* Inner Demon Quick Status & Master's Guidance */}
      <div className="mt-4 pt-3 border-t border-[#2c4438]/70 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        {/* Mentor Guidance Box */}
        <div className="flex items-start gap-2 text-xs text-[#9fb3a4] flex-1 bg-[#0a0f0e]/50 p-2.5 rounded-xl border border-[#2c4438]/60">
          <span className="text-base select-none shrink-0">🧭</span>
          <div className="flex-1 min-w-0">
            <span className="italic text-[#f2ead2]/90">"{currentMentor.quote}"</span>
            <span className="block text-[10px] text-[#5fe0a4] mt-0.5 font-cinzel">— {currentMentor.speaker}</span>
          </div>
          <button
            onClick={cycleMentor}
            aria-label="New teaching"
            className="text-[#9fb3a4] hover:text-[#5fe0a4] transition p-1 shrink-0 cursor-pointer"
            title="Hear another teaching"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Daily Demon Teaser */}
        {state.boss && (
          <button
            onClick={onNavigateToDemon}
            className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-[#0a0f0e] border border-[#2c4438] hover:border-rose-500/50 text-left transition cursor-pointer shrink-0 active:scale-98"
            title="View today's Inner Demon"
          >
            <span className="text-xl shrink-0">{state.boss.emoji}</span>
            <div className="min-w-0">
              <div className="text-[11px] text-[#9fb3a4] flex items-center gap-1">
                <span>Today's Demon</span>
                <Swords className="w-3 h-3 text-rose-400" />
              </div>
              <div className="font-cinzel text-xs font-bold text-[#f2ead2] truncate max-w-[140px]">
                {state.boss.defeated ? (
                  <span className="text-[#5fe0a4]">Subdued!</span>
                ) : (
                  <span>{state.boss.name}</span>
                )}
              </div>
            </div>
            {!state.boss.defeated && (
              <div className="w-12 h-1.5 bg-[#1c2b26] rounded-full overflow-hidden border border-[#2c4438]">
                <div
                  className="h-full bg-rose-500 transition-all"
                  style={{ width: `${Math.round((state.boss.hp / state.boss.maxHp) * 100)}%` }}
                />
              </div>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
