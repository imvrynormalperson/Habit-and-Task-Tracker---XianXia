import React, { useState } from 'react';
import { useCultivation } from '../context/CultivationContext';
import { getRealmForLevel, getMaxHpForLevel } from '../data/cultivationData';
import { Zap, Sparkles, X, Shield, ArrowRight } from 'lucide-react';

interface BreakthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BreakthroughModal: React.FC<BreakthroughModalProps> = ({ isOpen, onClose }) => {
  const { state, currentRealm, readyForBreakthrough, performBreakthrough } = useCultivation();
  const [isStriking, setIsStriking] = useState(false);
  const [successResult, setSuccessResult] = useState<{ newLevel: number } | null>(null);

  if (!isOpen) return null;

  const nextLevel = state.level + 1;
  const nextRealm = getRealmForLevel(nextLevel);
  const currentMaxHp = state.maxHp;
  const nextMaxHp = getMaxHpForLevel(nextLevel, (state.arrays.array_wall || 0) * 15);

  const handleBreakthrough = () => {
    setIsStriking(true);
    setTimeout(() => {
      const result = performBreakthrough();
      setIsStriking(false);
      if (result.success) {
        setSuccessResult({ newLevel: result.newLevel });
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className={`relative w-full max-w-md rounded-2xl bg-[#131f1c] border-2 ${isStriking ? 'border-amber-400 shadow-2xl shadow-amber-400/50' : 'border-[#d4af37]'} p-6 shadow-2xl text-center overflow-hidden transition-all`}>
        {/* Background Lightning Effect */}
        <div className="absolute inset-0 bg-radial from-[#d4af37]/10 via-transparent to-transparent pointer-events-none" />

        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-4 right-4 text-[#9fb3a4] hover:text-[#f2ead2] p-1 rounded-lg hover:bg-[#1c2b26] transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {!successResult ? (
          <>
            <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-tr from-[#d4af37] to-[#facc15] flex items-center justify-center text-[#0a0f0e] shadow-lg shadow-[#d4af37]/30 mb-4 animate-bounce">
              <Zap className="w-8 h-8 fill-current" />
            </div>

            <h2 className="font-cinzel font-bold text-xl text-[#f2ead2] mb-1">
              Heavenly Tribulation Rite
            </h2>
            <div className="text-xs text-[#5fe0a4] font-cinzel mb-4">
              渡劫破境 · Transcend Mortal Boundaries
            </div>

            <p className="text-xs text-[#9fb3a4] leading-relaxed mb-6">
              Your meridians are saturated with celestial spiritual energy. Divine lightning gathers above the clouds to forge your Dao Heart into a higher realm!
            </p>

            {/* Realm Comparison Card */}
            <div className="bg-[#0a0f0e] border border-[#2c4438] rounded-xl p-4 mb-6 flex items-center justify-between">
              <div className="text-center flex-1">
                <div className="text-2xl mb-1">{currentRealm.emoji}</div>
                <div className="font-cinzel text-xs font-bold text-[#9fb3a4]">Level {state.level}</div>
                <div className="text-[11px] text-[#f2ead2]">{currentRealm.name}</div>
              </div>

              <div className="px-3 text-[#d4af37] flex flex-col items-center">
                <ArrowRight className="w-5 h-5 animate-pulse" />
                <span className="text-[10px] font-mono mt-1">Ascend</span>
              </div>

              <div className="text-center flex-1">
                <div className="text-2xl mb-1">{nextRealm.emoji}</div>
                <div className="font-cinzel text-xs font-bold text-[#5fe0a4]">Level {nextLevel}</div>
                <div className="text-[11px] text-[#5fe0a4] font-semibold">{nextRealm.name}</div>
              </div>
            </div>

            {/* Stat Enhancements Preview */}
            <div className="text-xs text-left bg-[#1c2b26]/60 rounded-xl p-3 mb-6 space-y-1.5 border border-[#2c4438]">
              <div className="flex justify-between text-[#9fb3a4]">
                <span>Dao Heart Max Capacity:</span>
                <span className="font-mono text-[#5fe0a4] font-bold">
                  {currentMaxHp} → {nextMaxHp} (+{nextMaxHp - currentMaxHp})
                </span>
              </div>
              <div className="flex justify-between text-[#9fb3a4]">
                <span>Dao Heart Healing:</span>
                <span className="font-mono text-[#5fe0a4] font-bold">100% Fully Restored</span>
              </div>
              <div className="flex justify-between text-[#9fb3a4]">
                <span>Demon Strike Power:</span>
                <span className="font-mono text-[#d4af37] font-bold">+15% Base Damage</span>
              </div>
            </div>

            <button
              onClick={handleBreakthrough}
              disabled={isStriking || !readyForBreakthrough}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#facc15] to-[#eab308] text-[#0a0f0e] font-cinzel font-bold text-sm shadow-lg shadow-[#d4af37]/30 hover:brightness-110 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isStriking ? (
                <>
                  <Zap className="w-4 h-4 animate-spin text-[#0a0f0e]" />
                  <span>Channeling Heavenly Lightning...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#0a0f0e]" />
                  <span>Face Heavenly Lightning & Break Through</span>
                </>
              )}
            </button>
          </>
        ) : (
          <>
            <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-tr from-[#2f9e6e] to-[#5fe0a4] flex items-center justify-center text-[#08120e] shadow-lg shadow-[#2f9e6e]/40 mb-4 animate-bounce">
              <Shield className="w-8 h-8 fill-current" />
            </div>

            <h2 className="font-cinzel font-bold text-xl text-[#5fe0a4] mb-1">
              Breakthrough Complete!
            </h2>
            <div className="text-xs text-[#d4af37] font-cinzel mb-4">
              天劫已过 · New Realm Attained
            </div>

            <p className="text-xs text-[#f2ead2] leading-relaxed mb-6">
              You have survived the heavenly tribulation! The impurities in your flesh have burned away, leaving an enlightened golden core.
            </p>

            <button
              onClick={() => {
                setSuccessResult(null);
                onClose();
              }}
              className="w-full py-3 rounded-xl bg-[#2f9e6e] hover:bg-[#5fe0a4] text-[#08120e] font-cinzel font-bold text-sm shadow-md transition active:scale-98 cursor-pointer"
            >
              Continue Cultivation
            </button>
          </>
        )}
      </div>
    </div>
  );
};
