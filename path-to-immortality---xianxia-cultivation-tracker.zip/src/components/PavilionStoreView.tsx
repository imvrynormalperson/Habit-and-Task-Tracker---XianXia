import React from 'react';
import { useCultivation } from '../context/CultivationContext';
import { ROBE_SKINS, CAVE_ARRAYS } from '../data/cultivationData';
import { Shield, Sparkles, Check, ArrowUpRight } from 'lucide-react';

export const PavilionStoreView: React.FC = () => {
  const { state, buySkin, equipSkin, upgradeArray } = useCultivation();

  return (
    <div className="w-full space-y-6">
      {/* Header Info */}
      <div className="flex justify-between items-center bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4">
        <div>
          <h2 className="font-cinzel font-bold text-base sm:text-lg text-[#f2ead2]">
            Immortal Treasure Pavilion
          </h2>
          <p className="text-xs text-[#9fb3a4]">
            Acquire spiritual robes, cultivate your cave dwelling, and purchase mystical formations.
          </p>
        </div>
        <div className="text-right">
          <span className="text-xs text-[#9fb3a4] block">Available Funds</span>
          <div className="flex items-center gap-1 font-mono text-base font-bold text-[#5fe0a4]">
            <span>{state.coins}</span>
            <span className="text-xs text-[#d4af37]">Stones</span>
          </div>
        </div>
      </div>

      {/* Robes & Forms Section */}
      <div>
        <h3 className="font-cinzel text-xs font-bold text-[#9fb3a4] mb-3 uppercase tracking-wider">
          Cultivator Robes & Divine Forms
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {ROBE_SKINS.map(skin => {
            const isOwned = state.unlockedSkins.includes(skin.id);
            const isEquipped = state.activeSkin === skin.id;
            const canAfford = state.coins >= skin.cost;

            return (
              <div
                key={skin.id}
                className={`bg-[#131f1c] border rounded-2xl p-4 flex flex-col justify-between transition-all ${
                  isEquipped
                    ? 'border-[#5fe0a4] shadow-lg shadow-[#5fe0a4]/10'
                    : 'border-[#2c4438] hover:border-[#9fb3a4]'
                }`}
              >
                <div>
                  <div className="flex items-center gap-3 mb-2.5">
                    <div className="w-12 h-12 rounded-xl bg-[#0a0f0e] border border-[#2c4438] flex items-center justify-center text-2xl shrink-0">
                      {skin.emoji}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-cinzel font-bold text-sm text-[#f2ead2] truncate">
                        {skin.name}
                      </h4>
                      <div className="text-[11px] text-[#5fe0a4] font-medium">
                        {skin.title}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#9fb3a4] leading-relaxed mb-2.5">
                    {skin.description}
                  </p>

                  <div className="text-[11px] text-[#d4af37] bg-[#0a0f0e] p-2 rounded-lg border border-[#2c4438] mb-3">
                    <strong className="block text-[10px] text-[#9fb3a4] uppercase">Inherent Perk:</strong>
                    {skin.perk}
                  </div>
                </div>

                <div className="pt-2 border-t border-[#2c4438]/50 flex items-center justify-between">
                  <span className="font-mono text-xs text-[#9fb3a4]">
                    {isOwned ? 'Acquired' : `${skin.cost} Stones`}
                  </span>

                  {isEquipped ? (
                    <span className="px-3 py-1.5 rounded-xl bg-[#2f9e6e]/20 text-[#5fe0a4] border border-[#5fe0a4]/30 font-semibold text-xs flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Equipped
                    </span>
                  ) : isOwned ? (
                    <button
                      onClick={() => equipSkin(skin.id)}
                      className="px-3.5 py-1.5 rounded-xl bg-[#1c2b26] hover:bg-[#2c4438] text-[#f2ead2] text-xs font-semibold transition cursor-pointer"
                    >
                      Don Robe
                    </button>
                  ) : (
                    <button
                      onClick={() => buySkin(skin.id)}
                      disabled={!canAfford}
                      className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#2f9e6e] to-[#5fe0a4] text-[#08120e] font-cinzel font-bold text-xs hover:brightness-110 active:scale-95 transition disabled:opacity-40 cursor-pointer"
                    >
                      Attain Form
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cave Dwelling Arrays */}
      <div>
        <h3 className="font-cinzel text-xs font-bold text-[#9fb3a4] mb-3 uppercase tracking-wider">
          Cave Dwelling Spiritual Formations
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {CAVE_ARRAYS.map(arr => {
            const currentLevel = state.arrays[arr.id] || 0;
            const isMaxed = currentLevel >= arr.maxLevel;
            const nextCost = arr.baseCost + currentLevel * 40;
            const canAfford = state.coins >= nextCost;

            return (
              <div
                key={arr.id}
                className="bg-[#131f1c] border border-[#2c4438] rounded-2xl p-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-1.5">
                    <div>
                      <h4 className="font-cinzel font-bold text-sm text-[#f2ead2]">
                        {arr.name}
                      </h4>
                      <div className="text-[11px] text-[#5fe0a4]">
                        Formation Level {currentLevel} / {arr.maxLevel}
                      </div>
                    </div>

                    <div className="flex gap-1">
                      {Array.from({ length: arr.maxLevel }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2.5 h-2.5 rounded-full border border-[#0a0f0e] ${
                            i < currentLevel ? 'bg-[#5fe0a4]' : 'bg-[#2c4438]'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <p className="text-xs text-[#9fb3a4] leading-relaxed mb-3">
                    {arr.description}
                  </p>

                  <div className="text-xs text-[#d4af37] font-medium mb-3">
                    {arr.bonusText}
                  </div>
                </div>

                <div className="pt-2 border-t border-[#2c4438]/50 flex items-center justify-between">
                  <span className="font-mono text-xs text-[#9fb3a4]">
                    {isMaxed ? 'Maximum Inscription' : `Upgrade: ${nextCost} Stones`}
                  </span>

                  <button
                    onClick={() => upgradeArray(arr.id)}
                    disabled={isMaxed || !canAfford}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#eab308] text-[#0a0f0e] font-cinzel font-bold text-xs hover:brightness-110 active:scale-95 transition disabled:opacity-40 flex items-center gap-1 cursor-pointer"
                  >
                    <span>{isMaxed ? 'Max Inscribed' : 'Inscribe Array'}</span>
                    {!isMaxed && <ArrowUpRight className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
