import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { 
  CultivatorState, 
  Quest, 
  DemonBoss, 
  BattleLogEntry, 
  QuestDifficulty, 
  QuestCategory, 
  PillRecipe,
  HerbInventory 
} from '../types/cultivation';
import { 
  CULTIVATION_REALMS, 
  getRealmForLevel, 
  getQiNeededForLevel, 
  getMaxHpForLevel, 
  getBossMaxHpForLevel, 
  DEMON_POOL, 
  ACHIEVEMENTS_LIST, 
  INITIAL_QUESTS,
  PILL_RECIPES,
  CAVE_ARRAYS,
  ROBE_SKINS
} from '../data/cultivationData';
import { SoundEngine } from '../services/sound';
import confetti from 'canvas-confetti';

const STORAGE_KEY = 'xianxia_immortality_v2';
const LEGACY_KEY = 'xianxia_data_v1';

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

const DEFAULT_STATE: CultivatorState = {
  level: 1,
  xp: 0,
  hp: 100,
  maxHp: 100,
  coins: 60,
  streak: 0,
  bestStreak: 0,
  lastActiveDate: getTodayString(),
  prestige: 0,
  activeSkin: 'default',
  unlockedSkins: ['default'],
  shieldCharges: 1,
  freezeCharges: 1,
  qiBoostCharges: 0,
  coinBoostCharges: 0,
  soundEnabled: true,
  hapticsEnabled: true,
  quests: INITIAL_QUESTS,
  boss: null,
  battleLog: [],
  herbs: {
    ginseng: 2,
    dragonGrass: 2,
    netherLotus: 1,
    celestialDew: 1
  },
  arrays: {
    array_spirit: 0,
    array_wall: 0,
    array_fortune: 0,
    array_garden: 0
  },
  unlockedAchievements: [],
  historyLog: {
    [getTodayString()]: 0
  },
  stats: {
    totalCompleted: 0,
    bossesDefeated: 0,
    pillsRefined: 0,
    breakthroughsAchieved: 0,
    hasFallenBefore: false
  }
};

interface CultivationContextType {
  state: CultivatorState;
  currentRealm: ReturnType<typeof getRealmForLevel>;
  qiNeeded: number;
  readyForBreakthrough: boolean;
  toggleQuest: (id: string) => { xp: number; coins: number; crit: boolean; herbDropped?: string };
  addQuest: (title: string, type: 'daily' | 'side', difficulty: QuestDifficulty, category: QuestCategory, subtasks?: string[]) => void;
  deleteQuest: (id: string) => void;
  toggleSubtask: (questId: string, subtaskId: string) => void;
  strikeDemonWithSwordQi: () => { dmg: number; crit: boolean } | null;
  concoctPill: (recipe: PillRecipe) => boolean;
  buySkin: (skinId: string) => boolean;
  equipSkin: (skinId: string) => void;
  upgradeArray: (arrayId: string) => boolean;
  performBreakthrough: () => { success: boolean; newLevel: number };
  performAscension: () => boolean;
  exportBackupCode: () => string;
  importBackupCode: (code: string) => boolean;
  resetAllProgress: () => void;
  toggleSound: () => void;
  toggleHaptics: () => void;
}

const CultivationContext = createContext<CultivationContextType | null>(null);

export const CultivationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<CultivatorState>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_STATE, ...parsed };
      }
      // Check legacy migration
      const legacy = localStorage.getItem(LEGACY_KEY);
      if (legacy) {
        const old = JSON.parse(legacy);
        return {
          ...DEFAULT_STATE,
          level: old.level || 1,
          xp: old.xp || 0,
          hp: old.hp || 100,
          coins: old.coins || 50,
          streak: old.streak || 0,
          bestStreak: old.bestStreak || 0,
          shieldCharges: old.shieldCharges || 0,
          freezeCharges: old.freezeCharges || 0
        };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_STATE;
  });

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Storage quota or private browsing
    }
  }, [state]);

  // Generate boss for a date
  const generateBoss = useCallback((dateStr: string, level: number): DemonBoss => {
    const seed = dateStr.split('-').reduce((acc, val) => acc + parseInt(val, 10), 0) + level;
    const template = DEMON_POOL[seed % DEMON_POOL.length];
    const maxHp = getBossMaxHpForLevel(level);

    return {
      id: `boss_${dateStr}_${level}`,
      name: template.name,
      title: template.title,
      flavor: template.flavor,
      emoji: template.emoji,
      hp: maxHp,
      maxHp: maxHp,
      dateAssigned: dateStr,
      defeated: false,
      rewardStones: template.rewardStones + level * 3,
      rewardHerb: template.rewardHerb
    };
  }, []);

  // Daily Rollover check
  useEffect(() => {
    const today = getTodayString();
    if (state.lastActiveDate === today && state.boss) {
      return;
    }

    setState(prev => {
      let updatedStreak = prev.streak;
      let updatedHp = prev.hp;
      let updatedCoins = prev.coins;
      let updatedShields = prev.shieldCharges;
      let updatedFreezes = prev.freezeCharges;
      const logs: BattleLogEntry[] = [...prev.battleLog];

      // Check yesterday's dailies if date changed
      if (prev.lastActiveDate !== today) {
        const dailies = prev.quests.filter(q => q.type === 'daily');
        if (dailies.length > 0) {
          const missed = dailies.filter(q => !q.done);
          if (missed.length === 0) {
            // Perfect day!
            updatedStreak += 1;
            const newBest = Math.max(prev.bestStreak, updatedStreak);
            updatedHp = Math.min(prev.maxHp, updatedHp + 10);
            updatedCoins += 25;
            logs.unshift({
              id: 'log_' + Date.now(),
              text: `✨ Perfect cultivation day! Streak extended to ${updatedStreak} days. +25 Spirit Stones.`,
              kind: 'good',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
          } else if (updatedFreezes > 0) {
            // Freeze pill protected
            updatedFreezes -= 1;
            logs.unshift({
              id: 'log_' + Date.now(),
              text: `❄️ Glacial Streak Freeze Pill shattered! Preserved your ${updatedStreak}-day streak from backlash.`,
              kind: 'epic',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
          } else {
            // Heart shield or backlash
            const damage = Math.min(missed.length * 15, 60);
            if (updatedShields > 0) {
              updatedShields -= 1;
              logs.unshift({
                id: 'log_' + Date.now(),
                text: `🛡️ Heart Shield Pill absorbed the ${prev.boss?.name || 'Inner Demon'}'s nighttime ambush! Streak broken.`,
                kind: 'epic',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              });
            } else {
              updatedHp = Math.max(0, updatedHp - damage);
              updatedCoins = Math.max(0, updatedCoins - 15);
              logs.unshift({
                id: 'log_' + Date.now(),
                text: `💥 Neglected cultivation! Inner demons struck during meditation: -${damage} Dao Heart, -15 Stones.`,
                kind: 'bad',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              });
            }
            updatedStreak = 0;
          }
        }
      }

      // Check Dao Heart Collapse
      let newLevel = prev.level;
      let hasFallen = prev.stats.hasFallenBefore;
      if (updatedHp <= 0) {
        newLevel = Math.max(1, prev.level - 1);
        hasFallen = true;
        updatedHp = getMaxHpForLevel(newLevel, (prev.arrays.array_wall || 0) * 15);
        updatedCoins = Math.floor(updatedCoins / 2);
        logs.unshift({
          id: 'log_' + Date.now() + '_fall',
          text: `⚠️ Dao Heart collapsed into chaos! Level dropped to ${newLevel}, but spiritual breath is reborn.`,
          kind: 'bad',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });
      }

      // Reset daily quests to undone, keep side quests if not done
      const refreshedQuests = prev.quests
        .map(q => q.type === 'daily' ? { ...q, done: false } : q)
        .filter(q => q.type === 'daily' || !q.done);

      // Assign boss for today
      const newBoss = generateBoss(today, newLevel);

      return {
        ...prev,
        level: newLevel,
        hp: updatedHp,
        maxHp: getMaxHpForLevel(newLevel, (prev.arrays.array_wall || 0) * 15),
        coins: updatedCoins,
        streak: updatedStreak,
        bestStreak: Math.max(prev.bestStreak, updatedStreak),
        shieldCharges: updatedShields,
        freezeCharges: updatedFreezes,
        quests: refreshedQuests,
        boss: newBoss,
        lastActiveDate: today,
        battleLog: logs.slice(0, 15),
        stats: {
          ...prev.stats,
          hasFallenBefore: hasFallen
        }
      };
    });
  }, [state.lastActiveDate, state.boss, generateBoss]);

  const currentRealm = useMemo(() => getRealmForLevel(state.level), [state.level]);
  const qiNeeded = useMemo(() => getQiNeededForLevel(state.level), [state.level]);
  const readyForBreakthrough = state.xp >= qiNeeded;

  // Toggle Quest Complete
  const toggleQuest = useCallback((id: string) => {
    const quest = state.quests.find(q => q.id === id);
    if (!quest) return { xp: 0, coins: 0, crit: false };

    const willBeDone = !quest.done;
    const diffMultipliers: Record<QuestDifficulty, { xp: number; stones: number; bossDmg: number }> = {
      easy: { xp: 12, stones: 6, bossDmg: 15 },
      normal: { xp: 20, stones: 12, bossDmg: 25 },
      hard: { xp: 35, stones: 20, bossDmg: 45 },
      tribulation: { xp: 55, stones: 35, bossDmg: 70 }
    };

    const base = diffMultipliers[quest.difficulty] || diffMultipliers.normal;
    let earnedXp = base.xp;
    let earnedStones = base.stones;
    let bossDamage = base.bossDmg;

    // Passive array multipliers
    const spiritArrayLvl = state.arrays.array_spirit || 0;
    earnedXp = Math.round(earnedXp * (1 + spiritArrayLvl * 0.06 + (state.prestige * 0.08)));

    const fortuneArrayLvl = state.arrays.array_fortune || 0;
    earnedStones = Math.round(earnedStones * (1 + fortuneArrayLvl * 0.06 + (state.prestige * 0.08)));

    // Active potion charges
    let newQiCharges = state.qiBoostCharges;
    if (newQiCharges > 0) {
      earnedXp *= 2;
      newQiCharges -= 1;
    }

    let newCoinCharges = state.coinBoostCharges;
    if (newCoinCharges > 0) {
      earnedStones *= 2;
      newCoinCharges -= 1;
    }

    // Critical strike chance on demon
    const isCrit = Math.random() < (state.activeSkin === 'skin_sword' ? 0.28 : 0.16);
    if (isCrit) {
      bossDamage = Math.round(bossDamage * 1.8);
    }

    // Herb drop based on category
    let herbType: keyof HerbInventory | undefined;
    let herbName: string | undefined;
    if (willBeDone && Math.random() < 0.55) {
      if (quest.category === 'mind') {
        herbType = 'ginseng';
        herbName = 'Spirit Ginseng';
      } else if (quest.category === 'body') {
        herbType = 'dragonGrass';
        herbName = 'Dragon Bone Grass';
      } else if (quest.category === 'spirit') {
        herbType = 'netherLotus';
        herbName = 'Nether Lotus';
      } else {
        herbType = 'celestialDew';
        herbName = 'Celestial Dew';
      }
    }

    if (willBeDone) {
      if (state.soundEnabled) {
        if (isCrit) SoundEngine.critStrike();
        else SoundEngine.taskComplete();
      }
      if (state.hapticsEnabled) {
        SoundEngine.triggerHaptics(isCrit ? [40, 20, 50] : 35);
      }
    }

    const today = getTodayString();

    setState(prev => {
      const updatedQuests = prev.quests.map(q => {
        if (q.id === id) {
          return {
            ...q,
            done: willBeDone,
            lastCompletedDate: willBeDone ? today : q.lastCompletedDate,
            streak: willBeDone && q.type === 'daily' ? (q.streak || 0) + 1 : q.streak
          };
        }
        return q;
      });

      // Update boss health
      let updatedBoss = prev.boss;
      const logs = [...prev.battleLog];

      if (updatedBoss && !updatedBoss.defeated && willBeDone) {
        const newHp = Math.max(0, updatedBoss.hp - bossDamage);
        const defeated = newHp <= 0;

        if (defeated) {
          updatedBoss = { ...updatedBoss, hp: 0, defeated: true };
          if (state.soundEnabled) SoundEngine.demonDefeated();
          if (state.hapticsEnabled) SoundEngine.triggerHaptics([80, 50, 100]);
          confetti({
            particleCount: 50,
            spread: 70,
            origin: { y: 0.6 }
          });
          logs.unshift({
            id: 'log_' + Date.now(),
            text: `⚔️ Subdued ${updatedBoss.name}! Earned +${updatedBoss.rewardStones} Stones & rare ${updatedBoss.rewardHerb}.`,
            kind: 'epic',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          });
        } else {
          updatedBoss = { ...updatedBoss, hp: newHp };
          logs.unshift({
            id: 'log_' + Date.now(),
            text: `${isCrit ? '⚡ Critical Sword Qi! ' : '🗡️ '}-${bossDamage} damage dealt to ${updatedBoss.name}.`,
            kind: 'good',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          });
        }
      }

      // Herbs inventory update
      const updatedHerbs = { ...prev.herbs };
      if (herbType) {
        updatedHerbs[herbType] = (updatedHerbs[herbType] || 0) + 1;
      }
      if (updatedBoss?.defeated && prev.boss && !prev.boss.defeated) {
        updatedHerbs.celestialDew = (updatedHerbs.celestialDew || 0) + 1;
      }

      // History heatmap count
      const currentDayCount = prev.historyLog[today] || 0;
      const updatedHistory = {
        ...prev.historyLog,
        [today]: willBeDone ? currentDayCount + 1 : Math.max(0, currentDayCount - 1)
      };

      const finalCoins = willBeDone 
        ? prev.coins + earnedStones + (updatedBoss?.defeated && prev.boss && !prev.boss.defeated ? updatedBoss.rewardStones : 0)
        : Math.max(0, prev.coins - earnedStones);

      const finalXp = willBeDone ? prev.xp + earnedXp : Math.max(0, prev.xp - earnedXp);

      // Check achievements
      const completedCount = willBeDone ? prev.stats.totalCompleted + 1 : prev.stats.totalCompleted;
      const bossesCount = updatedBoss?.defeated && prev.boss && !prev.boss.defeated 
        ? prev.stats.bossesDefeated + 1 
        : prev.stats.bossesDefeated;

      const newAchievements = [...prev.unlockedAchievements];
      ACHIEVEMENTS_LIST.forEach(ach => {
        if (!newAchievements.includes(ach.id)) {
          if (
            (ach.id === 'first_step' && completedCount >= 1) ||
            (ach.id === 'streak_3' && prev.streak >= 3) ||
            (ach.id === 'streak_7' && prev.streak >= 7) ||
            (ach.id === 'streak_30' && prev.streak >= 30) ||
            (ach.id === 'demon_1' && bossesCount >= 1) ||
            (ach.id === 'demon_10' && bossesCount >= 10) ||
            (ach.id === 'level_5' && prev.level >= 5) ||
            (ach.id === 'level_10' && prev.level >= 10) ||
            (ach.id === 'rich_500' && finalCoins >= 500)
          ) {
            newAchievements.push(ach.id);
            logs.unshift({
              id: 'log_ach_' + Date.now(),
              text: `🏆 Attainment Unlocked: ${ach.title}! +${ach.rewardStones} Spirit Stones.`,
              kind: 'epic',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
          }
        }
      });

      return {
        ...prev,
        quests: updatedQuests,
        xp: finalXp,
        coins: finalCoins,
        qiBoostCharges: newQiCharges,
        coinBoostCharges: newCoinCharges,
        boss: updatedBoss,
        herbs: updatedHerbs,
        battleLog: logs.slice(0, 15),
        historyLog: updatedHistory,
        unlockedAchievements: newAchievements,
        stats: {
          ...prev.stats,
          totalCompleted: completedCount,
          bossesDefeated: bossesCount
        }
      };
    });

    return { xp: earnedXp, coins: earnedStones, crit: isCrit, herbDropped: herbName };
  }, [state.quests, state.arrays, state.prestige, state.qiBoostCharges, state.coinBoostCharges, state.activeSkin, state.soundEnabled, state.hapticsEnabled]);

  // Add a quest
  const addQuest = useCallback((
    title: string, 
    type: 'daily' | 'side', 
    difficulty: QuestDifficulty, 
    category: QuestCategory,
    subtaskTitles?: string[]
  ) => {
    const newQuest: Quest = {
      id: 'q_' + Date.now() + Math.random().toString(36).substring(2, 6),
      title: title.trim(),
      type,
      difficulty,
      category,
      done: false,
      streak: 0,
      subtasks: subtaskTitles?.filter(t => t.trim().length > 0).map(t => ({
        id: 'st_' + Math.random().toString(36).substring(2, 7),
        title: t.trim(),
        completed: false
      })),
      createdAt: new Date().toISOString()
    };

    if (state.soundEnabled) SoundEngine.purchase();
    setState(prev => ({
      ...prev,
      quests: [newQuest, ...prev.quests]
    }));
  }, [state.soundEnabled]);

  // Delete a quest
  const deleteQuest = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      quests: prev.quests.filter(q => q.id !== id)
    }));
  }, []);

  // Toggle subtask
  const toggleSubtask = useCallback((questId: string, subtaskId: string) => {
    setState(prev => ({
      ...prev,
      quests: prev.quests.map(q => {
        if (q.id === questId && q.subtasks) {
          const updatedSubs = q.subtasks.map(s => s.id === subtaskId ? { ...s, completed: !s.completed } : s);
          return { ...q, subtasks: updatedSubs };
        }
        return q;
      })
    }));
  }, []);

  // Strike Demon with accumulated Sword Qi
  const strikeDemonWithSwordQi = useCallback(() => {
    if (!state.boss || state.boss.defeated) return null;
    const isCrit = Math.random() < 0.25;
    const damage = Math.round((20 + state.level * 4) * (isCrit ? 1.75 : 1));

    if (state.soundEnabled) {
      if (isCrit) SoundEngine.critStrike();
      else SoundEngine.taskComplete();
    }
    if (state.hapticsEnabled) {
      SoundEngine.triggerHaptics(isCrit ? [50, 30, 60] : 40);
    }

    setState(prev => {
      if (!prev.boss) return prev;
      const newHp = Math.max(0, prev.boss.hp - damage);
      const defeated = newHp <= 0;
      let updatedBoss = { ...prev.boss, hp: newHp, defeated };
      const logs = [...prev.battleLog];

      if (defeated) {
        if (state.soundEnabled) SoundEngine.demonDefeated();
        confetti({ particleCount: 60, spread: 80, origin: { y: 0.6 } });
        logs.unshift({
          id: 'log_' + Date.now(),
          text: `🗡️ Slashed ${updatedBoss.name} with Sword Qi! Demon banished for the day!`,
          kind: 'epic',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });
      } else {
        logs.unshift({
          id: 'log_' + Date.now(),
          text: `🗡️ Channeled dantian Sword Qi: -${damage} damage to ${updatedBoss.name}.`,
          kind: 'good',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });
      }

      return {
        ...prev,
        boss: updatedBoss,
        battleLog: logs.slice(0, 15),
        coins: defeated ? prev.coins + updatedBoss.rewardStones : prev.coins,
        stats: {
          ...prev.stats,
          bossesDefeated: defeated ? prev.stats.bossesDefeated + 1 : prev.stats.bossesDefeated
        }
      };
    });

    return { dmg: damage, crit: isCrit };
  }, [state.boss, state.level, state.soundEnabled, state.hapticsEnabled]);

  // Concoct Pill
  const concoctPill = useCallback((recipe: PillRecipe): boolean => {
    if (state.coins < recipe.costStones) return false;
    for (const [herb, count] of Object.entries(recipe.ingredients)) {
      if ((state.herbs[herb as keyof HerbInventory] || 0) < (count || 0)) {
        return false;
      }
    }

    if (state.soundEnabled) SoundEngine.pillBrewed();
    if (state.hapticsEnabled) SoundEngine.triggerHaptics([40, 30, 40]);

    setState(prev => {
      const updatedHerbs = { ...prev.herbs };
      for (const [herb, count] of Object.entries(recipe.ingredients)) {
        const key = herb as keyof HerbInventory;
        updatedHerbs[key] = Math.max(0, updatedHerbs[key] - (count || 0));
      }

      let shields = prev.shieldCharges;
      let freezes = prev.freezeCharges;
      let qiBoosts = prev.qiBoostCharges;
      let coinBoosts = prev.coinBoostCharges;
      let hp = prev.hp;
      let maxHp = prev.maxHp;
      let xp = prev.xp;

      if (recipe.type === 'shield') shields += 1;
      else if (recipe.type === 'freeze') freezes += 1;
      else if (recipe.type === 'qiBoost') qiBoosts += 5;
      else if (recipe.type === 'coinBoost') coinBoosts += 5;
      else if (recipe.type === 'heal') hp = Math.min(maxHp, hp + 40);
      else if (recipe.type === 'elixir') {
        xp += 150;
        maxHp += 10;
        hp = Math.min(maxHp, hp + 50);
      }

      const logs = [...prev.battleLog];
      logs.unshift({
        id: 'log_' + Date.now(),
        text: `🏺 Alchemy Cauldron flashed with golden steam: Refined [${recipe.name}]!`,
        kind: 'good',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });

      return {
        ...prev,
        coins: prev.coins - recipe.costStones,
        herbs: updatedHerbs,
        shieldCharges: shields,
        freezeCharges: freezes,
        qiBoostCharges: qiBoosts,
        coinBoostCharges: coinBoosts,
        hp,
        maxHp,
        xp,
        battleLog: logs.slice(0, 15),
        stats: {
          ...prev.stats,
          pillsRefined: prev.stats.pillsRefined + 1
        }
      };
    });

    return true;
  }, [state.coins, state.herbs, state.soundEnabled, state.hapticsEnabled]);

  // Buy Skin
  const buySkin = useCallback((skinId: string): boolean => {
    const skin = ROBE_SKINS.find(s => s.id === skinId);
    if (!skin || state.coins < skin.cost || state.unlockedSkins.includes(skinId)) {
      return false;
    }

    if (state.soundEnabled) SoundEngine.purchase();

    setState(prev => ({
      ...prev,
      coins: prev.coins - skin.cost,
      unlockedSkins: [...prev.unlockedSkins, skinId],
      activeSkin: skinId
    }));
    return true;
  }, [state.coins, state.unlockedSkins, state.soundEnabled]);

  // Equip Skin
  const equipSkin = useCallback((skinId: string) => {
    if (!state.unlockedSkins.includes(skinId)) return;
    if (state.soundEnabled) SoundEngine.purchase();
    setState(prev => ({ ...prev, activeSkin: skinId }));
  }, [state.unlockedSkins, state.soundEnabled]);

  // Upgrade Array
  const upgradeArray = useCallback((arrayId: string): boolean => {
    const arrayDef = CAVE_ARRAYS.find(a => a.id === arrayId);
    const currentLevel = state.arrays[arrayId] || 0;
    if (!arrayDef || currentLevel >= arrayDef.maxLevel) return false;

    const cost = arrayDef.baseCost + currentLevel * 40;
    if (state.coins < cost) return false;

    if (state.soundEnabled) SoundEngine.purchase();

    setState(prev => {
      const nextLvl = (prev.arrays[arrayId] || 0) + 1;
      const updatedArrays = { ...prev.arrays, [arrayId]: nextLvl };
      const newMaxHp = getMaxHpForLevel(prev.level, (updatedArrays.array_wall || 0) * 15);

      return {
        ...prev,
        coins: prev.coins - cost,
        arrays: updatedArrays,
        maxHp: newMaxHp,
        hp: Math.min(newMaxHp, prev.hp + 15)
      };
    });
    return true;
  }, [state.arrays, state.coins, state.soundEnabled, state.level]);

  // Perform Breakthrough (Heavenly Tribulation)
  const performBreakthrough = useCallback(() => {
    if (state.xp < qiNeeded) return { success: false, newLevel: state.level };

    const newLevel = state.level + 1;
    const newMaxHp = getMaxHpForLevel(newLevel, (state.arrays.array_wall || 0) * 15);

    if (state.soundEnabled) SoundEngine.breakthrough();
    if (state.hapticsEnabled) SoundEngine.triggerHaptics([80, 50, 120]);

    confetti({
      particleCount: 100,
      spread: 90,
      origin: { y: 0.5 }
    });

    setState(prev => {
      const remainingXp = prev.xp - qiNeeded;
      const newRealm = getRealmForLevel(newLevel);
      const logs = [...prev.battleLog];

      logs.unshift({
        id: 'log_break_' + Date.now(),
        text: `⚡ Heavenly Tribulation Passed! Ascended to Level ${newLevel} (${newRealm.name})!`,
        kind: 'epic',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });

      return {
        ...prev,
        level: newLevel,
        xp: Math.max(0, remainingXp),
        maxHp: newMaxHp,
        hp: newMaxHp, // Fully heal on breakthrough!
        battleLog: logs.slice(0, 15),
        stats: {
          ...prev.stats,
          breakthroughsAchieved: prev.stats.breakthroughsAchieved + 1
        }
      };
    });

    return { success: true, newLevel };
  }, [state.xp, qiNeeded, state.level, state.arrays.array_wall, state.soundEnabled, state.hapticsEnabled]);

  // Perform Ascension (Prestige)
  const performAscension = useCallback(() => {
    if (state.level < 15) return false;

    if (state.soundEnabled) SoundEngine.breakthrough();
    confetti({ particleCount: 150, spread: 120, origin: { y: 0.4 } });

    setState(prev => {
      const newPrestige = prev.prestige + 1;
      const newLevel = 1;
      const newMaxHp = getMaxHpForLevel(1, (prev.arrays.array_wall || 0) * 15);
      const logs = [...prev.battleLog];

      logs.unshift({
        id: 'log_ascend_' + Date.now(),
        text: `🌌 Transcended Mortality! Ascension #${newPrestige} complete. Permanent +8% Qi & +8% Stones unlocked!`,
        kind: 'epic',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });

      return {
        ...prev,
        level: newLevel,
        xp: 0,
        prestige: newPrestige,
        maxHp: newMaxHp,
        hp: newMaxHp,
        coins: Math.max(50, Math.floor(prev.coins / 3)),
        herbs: {
          ...prev.herbs,
          celestialDew: prev.herbs.celestialDew + 3
        },
        battleLog: logs.slice(0, 15)
      };
    });

    return true;
  }, [state.level, state.soundEnabled]);

  // Export / Import
  const exportBackupCode = useCallback(() => {
    return btoa(unescape(encodeURIComponent(JSON.stringify(state))));
  }, [state]);

  const importBackupCode = useCallback((code: string) => {
    try {
      const parsed = JSON.parse(decodeURIComponent(escape(atob(code.trim()))));
      if (!parsed || typeof parsed !== 'object' || typeof parsed.level !== 'number') {
        return false;
      }
      setState({ ...DEFAULT_STATE, ...parsed });
      return true;
    } catch {
      return false;
    }
  }, []);

  const resetAllProgress = useCallback(() => {
    setState(DEFAULT_STATE);
  }, []);

  const toggleSound = useCallback(() => {
    setState(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  }, []);

  const toggleHaptics = useCallback(() => {
    setState(prev => ({ ...prev, hapticsEnabled: !prev.hapticsEnabled }));
  }, []);

  return (
    <CultivationContext.Provider value={{
      state,
      currentRealm,
      qiNeeded,
      readyForBreakthrough,
      toggleQuest,
      addQuest,
      deleteQuest,
      toggleSubtask,
      strikeDemonWithSwordQi,
      concoctPill,
      buySkin,
      equipSkin,
      upgradeArray,
      performBreakthrough,
      performAscension,
      exportBackupCode,
      importBackupCode,
      resetAllProgress,
      toggleSound,
      toggleHaptics
    }}>
      {children}
    </CultivationContext.Provider>
  );
};

export function useCultivation() {
  const context = useContext(CultivationContext);
  if (!context) {
    throw new Error('useCultivation must be used within CultivationProvider');
  }
  return context;
}
