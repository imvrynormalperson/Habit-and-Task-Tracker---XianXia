/**
 * Path to Immortality - Xianxia Cultivation Tracker
 * Production-ready Android PWA & Web Application
 */

import React, { useState } from 'react';
import { CultivationProvider, useCultivation } from './context/CultivationContext';
import { Header } from './components/Header';
import { CultivatorHUD } from './components/CultivatorHUD';
import { QuestSection } from './components/QuestSection';
import { DailyDemonView } from './components/DailyDemonView';
import { AlchemyCauldronView } from './components/AlchemyCauldronView';
import { PavilionStoreView } from './components/PavilionStoreView';
import { AttainmentsView } from './components/AttainmentsView';
import { MobileTabBar, MainTab } from './components/MobileTabBar';
import { BreakthroughModal } from './components/BreakthroughModal';
import { DaoScrollModal } from './components/DaoScrollModal';
import { CultivationGuideModal } from './components/CultivationGuideModal';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { Scroll, Swords, Flame, Sparkles, Compass, WifiOff } from 'lucide-react';
import heroBannerImg from './assets/images/cultivation_hero_banner_1790168721841.jpg';

const MainContent: React.FC = () => {
  const { state } = useCultivation();
  const isOnline = useOnlineStatus();

  const [activeTab, setActiveTab] = useState<MainTab>('quests');
  const [showBreakthrough, setShowBreakthrough] = useState(false);
  const [showDaoScroll, setShowDaoScroll] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  const navItems = [
    { id: 'quests' as MainTab, label: 'Cultivation', icon: Scroll },
    { id: 'demon' as MainTab, label: 'Inner Demon', icon: Swords, alert: state.boss && !state.boss.defeated },
    { id: 'alchemy' as MainTab, label: 'Cauldron', icon: Flame },
    { id: 'pavilion' as MainTab, label: 'Pavilion', icon: Sparkles },
    { id: 'path' as MainTab, label: 'Path & Realms', icon: Compass }
  ];

  return (
    <div className="min-h-screen bg-[#0a0f0e] text-[#f2ead2] flex flex-col relative pb-20 sm:pb-12">
      {/* Ambient Celestial Backdrop */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-25">
        <img
          src={heroBannerImg}
          alt="Celestial Sanctuary"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-top scale-105 blur-xs"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0f0e]/70 via-[#0a0f0e]/95 to-[#0a0f0e]" />
      </div>

      {/* Top App Bar */}
      <Header
        onOpenDaoScroll={() => setShowDaoScroll(true)}
        onOpenBreakthrough={() => setShowBreakthrough(true)}
        onOpenHelp={() => setShowHelp(true)}
      />

      {/* Offline Mode Indicator */}
      {!isOnline && (
        <div className="bg-amber-500/20 border-b border-amber-500/40 px-4 py-1.5 text-center text-xs text-amber-300 font-medium flex items-center justify-center gap-2 relative z-30">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode — All progress is saved locally and will persist automatically.</span>
        </div>
      )}

      {/* Main Body Container */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-3.5 sm:px-6 py-4 sm:py-6 relative z-10">
        {/* Cultivator HUD Header */}
        <CultivatorHUD
          onOpenBreakthrough={() => setShowBreakthrough(true)}
          onNavigateToDemon={() => setActiveTab('demon')}
        />

        {/* Desktop / Tablet Navigation Bar */}
        <div className="hidden sm:flex items-center gap-1.5 p-1 bg-[#131f1c] border border-[#2c4438] rounded-xl mb-6">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-cinzel font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-[#2f9e6e] text-[#08120e] shadow-md shadow-[#2f9e6e]/20'
                    : 'text-[#9fb3a4] hover:text-[#f2ead2] hover:bg-[#1c2b26]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
                {item.alert && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* View Routing */}
        <div className="transition-opacity duration-200">
          {activeTab === 'quests' && <QuestSection />}
          {activeTab === 'demon' && <DailyDemonView />}
          {activeTab === 'alchemy' && <AlchemyCauldronView />}
          {activeTab === 'pavilion' && <PavilionStoreView />}
          {activeTab === 'path' && <AttainmentsView />}
        </div>
      </main>

      {/* Mobile Bottom Tab Bar (Strictly complying with Mobile Touch Apps design reference) */}
      <div className="sm:hidden">
        <MobileTabBar
          activeTab={activeTab}
          onChangeTab={setActiveTab}
          demonDefeated={state.boss?.defeated}
        />
      </div>

      {/* Modals */}
      <BreakthroughModal
        isOpen={showBreakthrough}
        onClose={() => setShowBreakthrough(false)}
      />

      <DaoScrollModal
        isOpen={showDaoScroll}
        onClose={() => setShowDaoScroll(false)}
      />

      <CultivationGuideModal
        isOpen={showHelp}
        onClose={() => setShowHelp(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <CultivationProvider>
      <MainContent />
    </CultivationProvider>
  );
}
