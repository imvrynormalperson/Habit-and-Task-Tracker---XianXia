/**
 * Sound & Haptic Feedback Engine for Xianxia Cultivator
 * Synthesized purely in-browser using Web Audio API and navigator.vibrate
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export const SoundEngine = {
  playTone(freq: number, start: number, duration: number, type: OscillatorType = 'sine', volume = 0.08) {
    const ctx = getAudioContext();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);

      gain.gain.setValueAtTime(volume, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + start + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + duration);
    } catch {
      // Audio context may not be ready or muted
    }
  },

  // Task Completed: Gentle harp resonance
  taskComplete() {
    this.playTone(523.25, 0, 0.12, 'sine', 0.08); // C5
    this.playTone(659.25, 0.08, 0.14, 'sine', 0.07); // E5
    this.playTone(783.99, 0.16, 0.22, 'sine', 0.06); // G5
  },

  // Sword Slash / Critical Hit on Inner Demon
  critStrike() {
    this.playTone(880, 0, 0.08, 'sawtooth', 0.09);
    this.playTone(1320, 0.05, 0.12, 'triangle', 0.1);
    this.playTone(1760, 0.1, 0.25, 'sine', 0.08);
  },

  // Pill Concocted in Furnace
  pillBrewed() {
    this.playTone(392, 0, 0.1, 'sine', 0.06);
    this.playTone(587.33, 0.08, 0.15, 'sine', 0.08);
    this.playTone(880, 0.18, 0.3, 'triangle', 0.07);
  },

  // Heavenly Tribulation Lightning & Breakthrough
  breakthrough() {
    // Grand Gong & Ascending Chimes
    this.playTone(261.63, 0, 0.4, 'triangle', 0.12); // C4 gong
    this.playTone(392.0, 0.1, 0.35, 'sine', 0.1);
    this.playTone(523.25, 0.2, 0.35, 'sine', 0.1);
    this.playTone(659.25, 0.35, 0.35, 'sine', 0.1);
    this.playTone(783.99, 0.5, 0.4, 'sine', 0.12);
    this.playTone(1046.5, 0.65, 0.6, 'sine', 0.15); // C6
  },

  // Inner Demon Struck / Boss Defeated
  demonDefeated() {
    this.playTone(329.63, 0, 0.2, 'sawtooth', 0.09);
    this.playTone(440, 0.15, 0.25, 'triangle', 0.1);
    this.playTone(659.25, 0.3, 0.35, 'sine', 0.12);
    this.playTone(880, 0.45, 0.5, 'sine', 0.15);
  },

  // Damage taken / Backlash
  damage() {
    this.playTone(146.83, 0, 0.25, 'sawtooth', 0.12);
    this.playTone(110.0, 0.08, 0.3, 'sawtooth', 0.1);
  },

  // Shield absorbed
  shieldBlock() {
    this.playTone(440, 0, 0.08, 'sine', 0.07);
    this.playTone(660, 0.06, 0.12, 'sine', 0.08);
    this.playTone(880, 0.12, 0.2, 'triangle', 0.09);
  },

  // Purchase / Pavilion upgrade
  purchase() {
    this.playTone(587.33, 0, 0.08, 'sine', 0.07);
    this.playTone(880, 0.07, 0.15, 'sine', 0.08);
  },

  // Trigger haptic vibration on Android / mobile devices
  triggerHaptics(pattern: number | number[]) {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Ignored if user hasn't interacted or device does not support
      }
    }
  }
};
