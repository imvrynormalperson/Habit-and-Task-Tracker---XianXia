import { CultivationRealm, DemonBoss, PillRecipe, RobeSkin, CaveArray, Achievement, Quest } from '../types/cultivation';

export const CULTIVATION_REALMS: CultivationRealm[] = [
  {
    tier: 1,
    minLevel: 1,
    name: 'Mortal Realm',
    chineseName: '凡人境',
    description: 'A mortal flesh body stepping onto the perilous road of cultivation.',
    emoji: '🧑',
    color: '#9fb3a4'
  },
  {
    tier: 2,
    minLevel: 3,
    name: 'Qi Condensation',
    chineseName: '练气境',
    description: 'Sensing heaven and earth spiritual Qi, breathing in divine essence.',
    emoji: '🧘',
    color: '#5fe0a4'
  },
  {
    tier: 3,
    minLevel: 6,
    name: 'Foundation Establishment',
    chineseName: '筑基境',
    description: 'Forging the spiritual meridian river; the Dao heart becomes firm like granite.',
    emoji: '🌿',
    color: '#2f9e6e'
  },
  {
    tier: 4,
    minLevel: 9,
    name: 'Core Formation',
    chineseName: '结丹境',
    description: 'Spiritual Qi condenses into a shimmering golden core within the dantian.',
    emoji: '💠',
    color: '#38bdf8'
  },
  {
    tier: 5,
    minLevel: 12,
    name: 'Nascent Soul',
    chineseName: '元婴境',
    description: 'A spiritual avatar is birthed within, granting longevity and divine senses.',
    emoji: '🫧',
    color: '#818cf8'
  },
  {
    tier: 6,
    minLevel: 15,
    name: 'Soul Formation',
    chineseName: '化神境',
    description: 'Communing directly with heaven’s law; the soul wanders across mountains and seas.',
    emoji: '🔮',
    color: '#c084fc'
  },
  {
    tier: 7,
    minLevel: 18,
    name: 'Void Refinement',
    chineseName: '炼虚境',
    description: 'Merging physical form with spatial void; stepping outside the wheel of fate.',
    emoji: '🌪️',
    color: '#f472b6'
  },
  {
    tier: 8,
    minLevel: 21,
    name: 'Body Integration',
    chineseName: '合体境',
    description: 'Flesh, soul, and Dao merge into one celestial existence.',
    emoji: '🐲',
    color: '#fbbf24'
  },
  {
    tier: 9,
    minLevel: 24,
    name: 'Mahayana Realm',
    chineseName: '大乘境',
    description: 'Perfection of all mortal attainments; ready to face the celestial gate.',
    emoji: '🌌',
    color: '#d4af37'
  },
  {
    tier: 10,
    minLevel: 27,
    name: 'Tribulation Transcending',
    chineseName: '渡劫境',
    description: 'Enduring nine heavenly lightning strikes to shed mortal bone.',
    emoji: '⚡',
    color: '#eab308'
  },
  {
    tier: 11,
    minLevel: 30,
    name: 'Golden Immortal',
    chineseName: '金仙境',
    description: 'Immortal flesh, living as long as heaven and earth, free of worldly dust.',
    emoji: '🏮',
    color: '#4ade80'
  },
  {
    tier: 12,
    minLevel: 35,
    name: 'Heavenly Venerable',
    chineseName: '天尊境',
    description: 'Ruler of celestial constellations; boundless Dao, supreme enlightenment.',
    emoji: '👑',
    color: '#facc15'
  }
];

export function getRealmForLevel(level: number): CultivationRealm {
  let matched = CULTIVATION_REALMS[0];
  for (const realm of CULTIVATION_REALMS) {
    if (level >= realm.minLevel) {
      matched = realm;
    }
  }
  return matched;
}

export function getQiNeededForLevel(level: number): number {
  return 80 + (level - 1) * 25;
}

export function getMaxHpForLevel(level: number, wallBonus = 0): number {
  return 100 + (level - 1) * 10 + wallBonus;
}

export function getBossMaxHpForLevel(level: number): number {
  return 85 + (level - 1) * 15;
}

export const DEMON_POOL: Omit<DemonBoss, 'id' | 'hp' | 'maxHp' | 'dateAssigned' | 'defeated'>[] = [
  {
    name: 'Sloth Demon',
    title: 'Whisperer of Procrastination',
    flavor: 'Whispers sweetly into your ear: "Cultivate again tomorrow; today is for resting."',
    emoji: '🦥',
    rewardStones: 35,
    rewardHerb: 'Spirit Ginseng'
  },
  {
    name: 'Doubt Demon',
    title: 'Eroder of Resolve',
    flavor: 'Breeds uncertainty: "Are you truly capable of ascending the celestial path?"',
    emoji: '👻',
    rewardStones: 40,
    rewardHerb: 'Dragon Bone Grass'
  },
  {
    name: 'Distraction Chimera',
    title: 'Scavenger of Attention',
    flavor: 'Floods the mind with fleeting worldly desires and endless chaotic feeds.',
    emoji: '🌀',
    rewardStones: 38,
    rewardHerb: 'Nether Lotus'
  },
  {
    name: 'Wrath Shadow',
    title: 'Combustor of Calm',
    flavor: 'Ignites sudden fury over trivial friction, scorching your peaceful dantian.',
    emoji: '🔥',
    rewardStones: 45,
    rewardHerb: 'Celestial Dew'
  },
  {
    name: 'Anxiety Ghoul',
    title: 'Tormentor of Future Days',
    flavor: 'Paints catastrophic illusions of tomorrow before the sun has even set.',
    emoji: '🌑',
    rewardStones: 42,
    rewardHerb: 'Spirit Ginseng'
  },
  {
    name: 'Vanity Phantom',
    title: 'Seeker of Hollow Praise',
    flavor: 'Cares only for how spiritual prowess looks to outsiders, hollowing the Dao core.',
    emoji: '🪞',
    rewardStones: 50,
    rewardHerb: 'Dragon Bone Grass'
  },
  {
    name: 'Greed Beast',
    title: 'Insatiable Maw',
    flavor: 'Demands more without ever being grounded in the present task.',
    emoji: '💰',
    rewardStones: 48,
    rewardHerb: 'Celestial Dew'
  }
];

export const PILL_RECIPES: PillRecipe[] = [
  {
    id: 'shield_pill',
    name: 'Heart Shield Pill',
    chineseName: '护心丹',
    description: 'A jade-coated pill that forms an impervious barrier around the Dao Heart, blocking 1 demon backlash.',
    costStones: 40,
    ingredients: { ginseng: 1, dragonGrass: 1 },
    effectDescription: '+1 Heart Shield charge',
    type: 'shield'
  },
  {
    id: 'freeze_pill',
    name: 'Glacial Streak Freeze Pill',
    chineseName: '定界凝霜丹',
    description: 'Infused with ancient ice marrow, freezes time to protect your cultivation streak if a day is missed.',
    costStones: 55,
    ingredients: { netherLotus: 2, celestialDew: 1 },
    effectDescription: '+1 Streak Freeze charge',
    type: 'freeze'
  },
  {
    id: 'qi_elixir',
    name: 'Nine Heavens Qi Gathering Pill',
    chineseName: '九天聚气散',
    description: 'Refined from pure heavenly energy. Doubled Qi yield from your next 5 completed tasks.',
    costStones: 45,
    ingredients: { ginseng: 2 },
    effectDescription: '+5 Qi Boost charges (x2 Qi)',
    type: 'qiBoost'
  },
  {
    id: 'wealth_pill',
    name: 'Fortune Attraction Pill',
    chineseName: '纳财生灵丹',
    description: 'Drawn to spirit veins. Doubled spirit stone yield from your next 5 completed tasks.',
    costStones: 45,
    ingredients: { dragonGrass: 2 },
    effectDescription: '+5 Stone Boost charges (x2 Stones)',
    type: 'coinBoost'
  },
  {
    id: 'healing_elixir',
    name: 'Marrow Cleansing Salve',
    chineseName: '洗髓灵液',
    description: 'Instantly expels internal impurities and repairs damaged Dao Heart by 40 points.',
    costStones: 50,
    ingredients: { ginseng: 1, celestialDew: 1 },
    effectDescription: 'Instantly restores 40 Dao Heart',
    type: 'heal'
  },
  {
    id: 'golden_elixir',
    name: 'Supreme Golden Dan',
    chineseName: '太上金丹',
    description: 'The crowning achievement of alchemy. Instantly awards 150 Qi and +10 permanent max Dao Heart.',
    costStones: 120,
    ingredients: { ginseng: 3, dragonGrass: 3, netherLotus: 2, celestialDew: 2 },
    effectDescription: '+150 Qi & +10 Max Dao Heart',
    type: 'elixir'
  }
];

export const ROBE_SKINS: RobeSkin[] = [
  {
    id: 'default',
    name: 'Mortal Wanderer',
    title: 'Novice Disciple',
    cost: 0,
    emoji: '🧑',
    description: 'Plain hemp robes worn by cultivators taking their first steps.',
    perk: 'Standard cultivation baseline'
  },
  {
    id: 'skin_sword',
    name: 'Azure Blade Swordsman',
    title: 'Sword Sect Disciple',
    cost: 50,
    emoji: '🗡️',
    description: 'A sharp, wind-cutting silk robe with an ancient flying sword insignia.',
    perk: '+5% chance of critical Sword Qi strike on demons'
  },
  {
    id: 'skin_elder',
    name: 'Daoist Sage in Grey',
    title: 'Cave Hermit',
    cost: 75,
    emoji: '🧙',
    description: 'Weathered robes imbued with the serenity of a millennium in mountain caves.',
    perk: '+5% passive resistance against Dao Heart loss'
  },
  {
    id: 'skin_alchemist',
    name: 'Grand Cauldron Master',
    title: 'Medicine Valley Elder',
    cost: 130,
    emoji: '🏺',
    description: 'Scent of cinnabar and thousand-year ginseng clings to these flame-resistant robes.',
    perk: 'Earn extra spirit herbs when completing tasks'
  },
  {
    id: 'skin_thunder',
    name: 'Thunder Sovereign',
    title: 'Master of Lightning',
    cost: 180,
    emoji: '⚡',
    description: 'Robes woven with azure lightning silk, sparking with raw tribulation power.',
    perk: '+10% bonus Qi from Hard and Tribulation tasks'
  },
  {
    id: 'skin_fox',
    name: 'Nine-Tailed Celestial Fox',
    title: 'Spirit Realm Emissary',
    cost: 250,
    emoji: '🦊',
    description: 'Mythical nine-tailed spiritual aura enveloping the cultivator in ethereal grace.',
    perk: '+15% bonus Spirit Stones from all sources'
  },
  {
    id: 'skin_dragon',
    name: 'Golden Dragon Lord',
    title: 'Supreme Constellation Monarch',
    cost: 350,
    emoji: '🐉',
    description: 'Dragon scale mantle radiating primordial aura of the sovereign realms.',
    perk: '+10% Qi, +10% Stones, +15 Max Dao Heart'
  }
];

export const CAVE_ARRAYS: CaveArray[] = [
  {
    id: 'array_spirit',
    name: 'Spirit Gathering Array',
    description: 'Draws ambient celestial Qi directly into your residence.',
    baseCost: 80,
    currentLevel: 0,
    maxLevel: 5,
    bonusText: '+6% Qi gained from all tasks per level'
  },
  {
    id: 'array_wall',
    name: 'Nine Heavens Iron Defense Array',
    description: 'Reinforces the cave boundaries with unyielding earthen ward.',
    baseCost: 90,
    currentLevel: 0,
    maxLevel: 5,
    bonusText: '+15 Permanent Max Dao Heart per level'
  },
  {
    id: 'array_fortune',
    name: 'Golden Toad Fortune Pagoda',
    description: 'Channels spirit mineral veins to multiply worldly gains.',
    baseCost: 85,
    currentLevel: 0,
    maxLevel: 5,
    bonusText: '+6% Spirit Stones rewarded per level'
  },
  {
    id: 'array_garden',
    name: 'Spiritual Medicine Soil Field',
    description: 'Enriched soil where rare herbs blossom effortlessly.',
    baseCost: 100,
    currentLevel: 0,
    maxLevel: 3,
    bonusText: 'Chance to harvest bonus spiritual herbs on task completion'
  }
];

export const ACHIEVEMENTS_LIST: Achievement[] = [
  {
    id: 'first_step',
    title: 'First Step on the Dao',
    description: 'Complete your first cultivation task.',
    emoji: '🥾',
    rewardStones: 20,
    unlocked: false
  },
  {
    id: 'streak_3',
    title: 'Three Days of Diligence',
    description: 'Maintain a 3-day cultivation streak.',
    emoji: '🔥',
    rewardStones: 30,
    unlocked: false
  },
  {
    id: 'streak_7',
    title: 'Seven Star Foundation',
    description: 'Maintain a 7-day cultivation streak.',
    emoji: '⭐',
    rewardStones: 60,
    unlocked: false
  },
  {
    id: 'streak_30',
    title: 'Immortal Will of Steel',
    description: 'Maintain a 30-day cultivation streak without interruption.',
    emoji: '👑',
    rewardStones: 200,
    unlocked: false
  },
  {
    id: 'demon_1',
    title: 'Demon Vanquisher',
    description: 'Defeat your first daily Inner Demon.',
    emoji: '⚔️',
    rewardStones: 40,
    unlocked: false
  },
  {
    id: 'demon_10',
    title: 'Master of Inner Peace',
    description: 'Slay 10 Inner Demons.',
    emoji: '🛡️',
    rewardStones: 120,
    unlocked: false
  },
  {
    id: 'pill_1',
    title: 'First Flame of Alchemy',
    description: 'Concoct your first pill in the Alchemy Cauldron.',
    emoji: '🏺',
    rewardStones: 35,
    unlocked: false
  },
  {
    id: 'pill_10',
    title: 'Grandmaster Alchemist',
    description: 'Concoct 10 medicinal pills.',
    emoji: '🧪',
    rewardStones: 100,
    unlocked: false
  },
  {
    id: 'level_5',
    title: 'Qi Condensation Adept',
    description: 'Reach Cultivator Level 5.',
    emoji: '🌿',
    rewardStones: 50,
    unlocked: false
  },
  {
    id: 'level_10',
    title: 'Golden Core Complete',
    description: 'Reach Cultivator Level 10.',
    emoji: '💠',
    rewardStones: 100,
    unlocked: false
  },
  {
    id: 'ascension_1',
    title: 'Heavenly Ascension',
    description: 'Complete an Ascension ceremony at Core Formation (Level 15+).',
    emoji: '⚡',
    rewardStones: 250,
    unlocked: false
  },
  {
    id: 'rich_500',
    title: 'Spirit Stone Magnate',
    description: 'Accumulate 500 Spirit Stones.',
    emoji: '💎',
    rewardStones: 100,
    unlocked: false
  }
];

export const INITIAL_QUESTS: Quest[] = [
  {
    id: 'q_meditation',
    title: 'Morning Spiritual Breathing & Mindfulness (15 min)',
    type: 'daily',
    difficulty: 'normal',
    category: 'spirit',
    done: false,
    streak: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_exercise',
    title: 'Physical Foundation: 30 min movement or workout',
    type: 'daily',
    difficulty: 'normal',
    category: 'body',
    done: false,
    streak: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_focus_craft',
    title: 'Deep Work: 60 minutes uninterrupted craft/study',
    type: 'daily',
    difficulty: 'hard',
    category: 'mind',
    done: false,
    streak: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_hydration',
    title: 'Drink 2 Liters of Pure Spring Water',
    type: 'daily',
    difficulty: 'easy',
    category: 'body',
    done: false,
    streak: 0,
    createdAt: new Date().toISOString()
  },
  {
    id: 'q_side_reading',
    title: 'Read 20 pages of Daoist wisdom or craft book',
    type: 'side',
    difficulty: 'normal',
    category: 'mind',
    done: false,
    createdAt: new Date().toISOString()
  }
];

export const MENTOR_QUOTES = [
  {
    quote: "A journey of ten thousand li begins beneath your immediate footstep. Do not gaze into the heavens while stumbling over today's stone.",
    speaker: "Dao Master Yuan"
  },
  {
    quote: "The demon in your mind is fed only by hesitation. Pick up your brush, swing your sword, and the fog naturally parts.",
    speaker: "Sword Immortal Bai"
  },
  {
    quote: "Consistency is the supreme alchemy. Even ordinary water dripping upon mountain granite will pierce through the stone in time.",
    speaker: "Elder Gu"
  },
  {
    quote: "When your Dao Heart wavers, close your eyes and remember: even immortals were once mortals who refused to quit.",
    speaker: "Matriarch Ling"
  },
  {
    quote: "Dusk approaches. Has today's spiritual vow been upheld, or has the Sloth Demon claimed victory in your dwelling?",
    speaker: "Dao Master Yuan"
  }
];
