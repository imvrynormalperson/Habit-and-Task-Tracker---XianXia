import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const source = path.resolve('./src/assets/images/app_icon_celestial_1790168759056.jpg');
const publicDir = path.resolve('./public');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

async function run() {
  console.log('Generating PWA icons from:', source);

  // 192x192
  await sharp(source)
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));

  // 512x512
  await sharp(source)
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));

  // apple-touch-icon (180x180)
  await sharp(source)
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));

  // maskable 512x512 with 15% safe-zone margin (inner icon 410x410 centered on #0a0f0e)
  const innerResized = await sharp(source)
    .resize(410, 410)
    .toBuffer();

  await sharp({
    create: {
      width: 512,
      height: 512,
      channels: 4,
      background: { r: 10, g: 15, b: 14, alpha: 1 }
    }
  })
    .composite([{ input: innerResized, top: 51, left: 51 }])
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));

  // favicon.ico
  await sharp(source)
    .resize(64, 64)
    .png()
    .toFile(path.join(publicDir, 'favicon.ico'));

  // icon.svg
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
    <rect width="512" height="512" rx="128" fill="#0a0f0e"/>
    <circle cx="256" cy="256" r="210" fill="#131f1c" stroke="#2f9e6e" stroke-width="12"/>
    <circle cx="256" cy="256" r="170" fill="none" stroke="#d4af37" stroke-width="6" stroke-dasharray="16 12"/>
    <path d="M256,86 A170,170 0 0,1 256,426 A85,85 0 0,1 256,256 A85,85 0 0,0 256,86" fill="#2f9e6e"/>
    <circle cx="256" cy="171" r="28" fill="#0a0f0e"/>
    <circle cx="256" cy="341" r="28" fill="#5fe0a4"/>
    <circle cx="256" cy="256" r="20" fill="#d4af37"/>
  </svg>`;
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), svg, 'utf-8');

  console.log('All icons generated successfully!');
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
